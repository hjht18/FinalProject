package com.example.demo.user.form;

import com.example.demo.user.UserVO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserForm {

	private String nickname;
	private String name;
	private String birth;
	private String phoneNum;
	private String zipCode;
	private String basicAddress;
	private String detailAddress;
	private String image;
	
	public UserForm(UserVO vo) {
		nickname = vo.getNickname();
		name = vo.getName();
		birth = vo.getBirth();
		phoneNum = vo.getPhoneNum();
		zipCode = vo.getZipCode();
		basicAddress = vo.getBasicAddress();
		detailAddress = vo.getDetailAddress();
		image = vo.getImage();
	}
}
