package com.example.demo.user.form;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserUpdateForm {

	private String nickname;
	private String name;
	private String password;
	private String birth;
	private String phoneNum;
	private String zipCode;
	private String basicAddress;
	private String detailAddress;
	private String image;
	
}
