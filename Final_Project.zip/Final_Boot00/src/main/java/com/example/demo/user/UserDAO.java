package com.example.demo.user;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;

import org.springframework.stereotype.Repository;

import lombok.RequiredArgsConstructor;

@Repository
@RequiredArgsConstructor
public class UserDAO {

	private final EntityManager em;
	
	public void save(UserVO vo) {
		em.persist(vo);
	}
	
	public UserVO findOne(Long id) {
		return em.find(UserVO.class, id);
	}
	
	public List<UserVO> findAll(){
		return em.createQuery("select u from UserVO u", UserVO.class).getResultList();
	}
	
	public void delete(UserVO vo) {
		em.remove(vo);
	}
	
	public Optional<UserVO> findByLoginId(String nickname){
		return findAll()
				.stream()
				.filter(u -> u.getNickname().equals(nickname)).findFirst();
	}
}
