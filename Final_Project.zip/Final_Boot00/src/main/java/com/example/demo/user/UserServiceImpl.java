package com.example.demo.user;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.user.form.UserForm;
import com.example.demo.user.form.UserUpdateForm;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class UserServiceImpl implements UserService{
	
	private final UserDAO dao;
	
	@Override
	@Transactional
	public void save(UserVO vo) {
		dao.save(vo);
	}

	@Override
	public UserForm findOne(Long id) {
		return new UserForm(dao.findOne(id));
	}

	@Override
	@Transactional
	public void update(Long id, UserUpdateForm form) {
		
		UserVO vo = dao.findOne(id);
		vo.setBasicAddress(form.getBasicAddress());
		vo.setDetailAddress(form.getDetailAddress());
		vo.setBirth(form.getBirth());
		vo.setName(form.getName());
		vo.setNickname(form.getNickname());
		vo.setPhoneNum(form.getPhoneNum());
		vo.setZipCode(form.getZipCode());
	}

	@Override
	@Transactional
	public void delete(Long id) {
		UserVO vo = dao.findOne(id);
		dao.delete(vo);
	}

	@Override
	public UserVO login(String nickname, String password) {
		return dao.findByLoginId(nickname)
		.filter(u -> u.getPassword().equals(password)).orElse(null);
	}
}
