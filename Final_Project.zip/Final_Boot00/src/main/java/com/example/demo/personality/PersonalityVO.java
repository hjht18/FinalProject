package com.example.demo.personality;

public class PersonalityVO {

}
