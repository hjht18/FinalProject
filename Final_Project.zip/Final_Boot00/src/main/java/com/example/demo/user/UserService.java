package com.example.demo.user;

import com.example.demo.user.form.UserForm;
import com.example.demo.user.form.UserUpdateForm;

public interface UserService {
	
	public void save(UserVO vo);
	
	public UserForm findOne(Long id);
	
	public void update(Long id, UserUpdateForm form);
	
	public void delete(Long id);
	
	public UserVO login(String nickname, String password);
}
