package com.example.demo.board;

public interface BoardService {

}
