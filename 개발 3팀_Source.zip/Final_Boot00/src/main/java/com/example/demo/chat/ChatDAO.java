package com.example.demo.chat;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import lombok.RequiredArgsConstructor;

@Repository
@RequiredArgsConstructor
public class ChatDAO {

	@PersistenceContext
	private final EntityManager em;
	
	// 메타데이터
	public List<ChatVO> chatMetaData(){
		return em.createQuery("select ch from ChatVO ch", ChatVO.class)
				.getResultList();
	}
	
	// 채팅 목록 조회
	public List<ChatVO> chatList(int room){
		return em.createQuery("select ch from ChatVO ch where ch.room =: room order by ch.id asc", ChatVO.class)
				.setParameter("room", room)
				.getResultList();
	}
	
	// 가장 최근 채팅 조회
	public ChatVO latestChat(int room) {
		return em.createQuery("select ch from ChatVO ch where ch.room =: room and ch.id = (select max(cht.id) from ChatVO cht)",
				ChatVO.class)
				.setParameter("room", room)
				.getResultList().get(0);
		
	}
	
	// 채팅 저장
	public void save(ChatVO vo) {
		em.persist(vo);
	}
	
	
}
