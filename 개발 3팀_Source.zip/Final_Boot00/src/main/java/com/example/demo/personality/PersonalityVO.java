package com.example.demo.personality;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.example.demo.user.UserVO;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "USER_PERSONALITY")
@SequenceGenerator(name = "PERSONALITY_CODE_GEN", 
sequenceName = "PERSONALITY_SEQ", 
allocationSize = 1, 
initialValue = 1)
public class PersonalityVO {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE,
					generator = "PERSONALITY_CODE_GEN")
	@Column(name = "PERSONALITY_CODE")
	private Long code;
	
	@Column(name = "GENDER")
	private String gender;
	
	@Column(name = "AGES")
	private String ages;
	
	@Column(name = "PLAN")
	private String plan;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "USER_CODE")
	private UserVO user;
}
