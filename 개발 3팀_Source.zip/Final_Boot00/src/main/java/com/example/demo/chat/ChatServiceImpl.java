package com.example.demo.chat;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ChatServiceImpl implements ChatService{
	
	private final ChatDAO dao;
	
	
	
	@Override
	public List<ChatVO> chatList(int room) {
		return dao.chatList(room);
	}

	@Override
	public ChatVO latestChat(int room) {
		return dao.latestChat(room);
	}

	@Override
	@Transactional
	public void save(ChatVO vo) {
		dao.save(vo);
	}

	@Override
	public List<ChatVO> chatMetaData() {
		return dao.chatMetaData();
	}

	
}
