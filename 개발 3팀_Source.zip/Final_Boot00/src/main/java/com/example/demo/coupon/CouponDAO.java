package com.example.demo.coupon;

import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.stereotype.Repository;

import lombok.RequiredArgsConstructor;

@Repository
@RequiredArgsConstructor
public class CouponDAO {

	private final EntityManager em;
	
	// 쿠폰 발행
	public void save(CouponVO vo) {
		em.persist(vo);
	}
	// 쿠폰 수정
	
	// 쿠폰 조회
	public CouponVO findOne(Long code) {
		return em.createQuery("select c from CouponVO c join fetch c.user = u join fetch c.order = o where code =: code", CouponVO.class)
		.setParameter("code", code).getResultList().get(0);
	}
	
	// 쿠폰 전체 조회
	public List<CouponVO> findAll() {
		return em.createQuery("select c from CouponVO c  join fetch c.user = u join fetch c.order = o ", CouponVO.class).getResultList();
	}
	
	// 쿠폰 삭제
	public void delete(CouponVO vo) {
		em.remove(vo);
	}
}
