package com.example.demo.chat;

import java.util.List;

public interface ChatService {
	
	List<ChatVO> chatMetaData();

	List<ChatVO> chatList(int room);
	
	ChatVO latestChat(int room);
	
	void save(ChatVO vo);
}
