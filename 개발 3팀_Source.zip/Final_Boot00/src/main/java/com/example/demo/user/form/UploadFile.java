package com.example.demo.user.form;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UploadFile {

	 // 업로드 파일 명
	 private String uploadFileName;
	 // 실제 서버 내부에서 관리하는 파일명
	 private String storeFileName;
	 
	 public UploadFile(String uploadFileName, String storeFileName) {
	 this.uploadFileName = uploadFileName;
	 this.storeFileName = storeFileName;
	 }
}
