package com.example.demo.user;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class UserServiceImpl implements UserService{
	
//	private final UserDAO dao;
	private final UserRepository dao;
	
	@Override
	@Transactional
	public void save(UserVO vo) {
		dao.save(vo);
	}

	@Override
	@Transactional
	public void update(Long code, UserVO vo) {
		
		UserVO user = dao.findByCode(code);
		user.setBasicAddress(vo.getBasicAddress());
		user.setDetailAddress(vo.getDetailAddress());
		user.setGender(vo.getGender());
		user.setPassword(vo.getPassword());
		user.setName(vo.getName());
		user.setId(vo.getId());
		user.setImage(vo.getImage());
		user.setPhoneNum(vo.getPhoneNum());
		user.setZipCode(vo.getZipCode());
	}

	@Override
	public UserVO findOne(Long code) {
		return dao.findByCode(code);
	}
	
	@Override
	@Transactional
	public void delete(Long code) {
		UserVO vo = dao.findByCode(code);
		dao.delete(vo);
	}

	@Override
	public UserVO login(String id, String password) {
		return dao.findById(id)
		.filter(u -> u.getPassword().equals(password)).orElse(null);
	}

	@Override
	public List<UserVO> findAll() {
		return dao.findAll();
	}
}
