package com.example.demo.free;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.example.demo.user.UserVO;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "FREE")
@SequenceGenerator(name = "FREE_CODE_GEN", 
sequenceName = "FREE_SEQ", 
allocationSize = 1, 
initialValue = 1)
public class FreeVO {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE,
					generator = "FREE_CODE_GEN")
	@Column(name = "FREE_CODE")
	private Long code; 
	
	@Column(name = "FREE_TITLE")
	private String title;
	
	@Column(name = "FREE_DATE")
	private String date;
	
	@Column(name = "FREE_CONTENT", length = 3000)
	private String content;
	
	@Column(name = "FREE_IMAGE")
	private String image;
	
	@Column(name = "VIEW_COUNT")
	private int viewCount;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "USER_CODE")
	private UserVO user;
	
}
