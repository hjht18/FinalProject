package com.example.demo.user;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.user.form.UserLoginForm;

import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@CrossOrigin
public class UserController {
	
	@Value("${userFile.dir}")
	private String fileDir;

	private final UserService service;

	// 유저 저장
	@PostMapping("/user")
	public void save(@RequestBody UserVO vo) {
		service.save(vo);
	}

	// 유저 조회
	@GetMapping("/user/{code}")
	public UserVO findOne(@PathVariable Long code) {
		return service.findOne(code);
	}
	
	@GetMapping("/users")
	public List<UserVO> findAll(){
		return service.findAll();
	}

	// 유저 수정
	@PatchMapping("/user/{code}")
	public void update(@PathVariable Long code, @RequestBody UserVO vo) {
		service.update(code, vo);
	}

	// 유저 삭제
	@DeleteMapping("/user/{code}")
	public void delete(@PathVariable Long code) {
		service.delete(code);
	}

	// 로그인
	@PostMapping("/login")
	public UserVO login(@RequestBody UserLoginForm form, HttpServletRequest request) {
		UserVO loginMember = service.login(form.getId(), form.getPassword());

//		if (loginMember == null) {
//			return false;
//		}
		HttpSession session = request.getSession();
		session.setAttribute("loginMember", loginMember);
		return loginMember;
	}

	// 로그아웃
	@PostMapping("/logout")
	public Boolean logout(HttpServletRequest request) {
		HttpSession session = request.getSession(false);
		if (session != null) {
			session.invalidate();
		}
		return false;
	}
	
	// 이미지 업로드
	@PostMapping("/userImage")
	public void imageDownload(@RequestBody MultipartFile file) throws IllegalStateException, IOException {
		File newFile = new File(fileDir + "/" + file.getOriginalFilename());
		if(!newFile.exists()) {
			newFile.mkdirs();
		}
		
		if(!file.isEmpty()) {
			file.transferTo(newFile);
		}
		
		System.out.println(file);
	}

}
