package com.example.demo.coupon;

import java.util.List;

public interface CouponService {
	
	void save(CouponVO vo);
	
	CouponVO findOne(Long code);
	
	List<CouponVO> findAll();
	
	void update(CouponVO vo, Long code);
	
	void delete(Long code);

}
