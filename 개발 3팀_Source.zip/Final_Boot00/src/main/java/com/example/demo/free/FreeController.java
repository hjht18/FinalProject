package com.example.demo.free;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@CrossOrigin
public class FreeController {

	private final FreeService service;

	@Value("${boardFile.dir}")
	private String fileDir;

	@PostMapping("/free")
	public void save(@RequestBody FreeVO vo) {
		service.save(vo);
	}

	// 게시판 조회
	@GetMapping("/free/{code}")
	public FreeVO findOne(@PathVariable Long code) {
		return service.findOne(code);
	}

	// 게시글 총 개수
	@GetMapping("/getTotalFreeNum")
	public Long getTotalNum() {
		return service.getTotalNum();
	}

	// 게시판 목록 조회
	@GetMapping("/frees/{page}")
	public List<FreeVO> findList(@PathVariable int page) {
		List<FreeVO> freeList = service.findList(page - 1);
		return freeList;
	}

	// 게시판 검색
	@GetMapping("/frees/title/{page}/{title}")
	public List<FreeVO> findByTitleContaining(@PathVariable int page, @PathVariable String title) {
		List<FreeVO> freeList = service.findByTitleContaining(page - 1, title);
		return freeList;
	}

	// 게시판 검색
	@GetMapping("/frees/content/{page}/{content}")
	public List<FreeVO> findByContentContaining(@PathVariable int page, @PathVariable String content) {
		List<FreeVO> freeList = service.findByContentContaining(page - 1, content);
		return freeList;
	}

	// 게시판 검색
	@GetMapping("/frees/name/{page}/{name}")
	public List<FreeVO> findByUserNameContaining(@PathVariable int page, @PathVariable String name) {
		List<FreeVO> freeList = service.findByUserNameContaining(page - 1, name);
		return freeList;
	}

	// 게시판 수정
	@PatchMapping("/free/{code}")
	public void update(@PathVariable Long code, @RequestBody FreeVO vo) {
		service.update(code, vo);
	}

	// 게시판 삭제
	@DeleteMapping("/free/{code}")
	public void delete(@PathVariable Long code) {
		service.delete(code);
	}

	// 이미지 업로드
	@PostMapping("/freeImage")
	public void imageDownload(@RequestBody MultipartFile file) throws IllegalStateException, IOException {
		File newFile = new File(fileDir + "/" + file.getOriginalFilename());
		if (!newFile.exists()) {
			newFile.mkdirs();
		}

		if (!file.isEmpty()) {
			file.transferTo(newFile);
		}

		System.out.println(file);
	}

}
