package com.example.demo.free;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.EntityGraph.EntityGraphType;
import org.springframework.data.jpa.repository.JpaRepository;


public interface FreeRepository extends JpaRepository<FreeVO, Long>{

	public FreeVO save(FreeVO vo);
	
	@EntityGraph(attributePaths = {"user"}, type = EntityGraphType.LOAD)
	public FreeVO findByCode(Long code);
	
	@EntityGraph(attributePaths = {"user"}, type = EntityGraphType.LOAD)
	public Page<FreeVO> findByTitleContaining(Pageable pageable, String title);
	
	@EntityGraph(attributePaths = {"user"}, type = EntityGraphType.LOAD)
	public Page<FreeVO> findByContentContaining(Pageable pageable, String content);
	
	@EntityGraph(attributePaths = {"user"}, type = EntityGraphType.LOAD)
	public Page<FreeVO> findByUserNameContaining(Pageable pageable, String name);
	
	@EntityGraph(attributePaths = {"user"}, type = EntityGraphType.LOAD)
	public Page<FreeVO> findAll(Pageable pageable);
	
	public void delete(FreeVO vo);
	
	
}
