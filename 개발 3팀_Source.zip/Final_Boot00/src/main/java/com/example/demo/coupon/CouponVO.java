package com.example.demo.coupon;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.example.demo.order.OrderVO;
import com.example.demo.user.UserVO;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "COUPON")
@SequenceGenerator(name = "COUPON_CODE_GEN", 
sequenceName = "COUPON_SEQ", 
allocationSize = 1, 
initialValue = 1)
public class CouponVO {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE,
					generator = "COUPON_CODE_GEN")
	@Column(name = "COUPON_CODE")
	private Long code;
	
	@Column(name = "LOCATION")
	private String location;
	
	@Column(name = "STORE")
	private String store;
	
	@Column(name = "PRICE")
	private String price;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "USER_CODE")
	private UserVO user;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "PAY_CODE")
	private OrderVO order;
}
