package com.example.demo.user;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.web.multipart.MultipartFile;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "USERS")
@SequenceGenerator(name = "USER_CODE_GEN", 
					sequenceName = "USER_SEQ", 
					allocationSize = 1, 
					initialValue = 1)
public class UserVO {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE,
					generator = "USER_CODE_GEN")
	@Column(name = "CODE")
	private Long code;
	
	@Column(name = "ID")
	private String id;
	
	@Column(name = "NAME")
	private String name;
	
	@Column(name = "PASSWORD")
	private String password;
	
	@Column(name = "GENDER")
	private String gender;
	
	@Column(name = "PHONE_NUM")
	private String phoneNum;
	
	@Column(name = "ZIPCODE")
	private String zipCode;
	
	@Column(name = "ADDRESS_BASIC")
	private String basicAddress;
	
	@Column(name = "ADDRESS_DETAIL")
	private String detailAddress;
	
	@Column(name = "USER_IMAGE")
	private String image;
	
	@Column(name = "ROLE")
	private int role;
	
	  public UserVO() {
	     this.role = 0;
	  }
}
