package com.example.demo.order;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.example.demo.coupon.CouponVO;
import com.example.demo.user.UserVO;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "ORDERS")
@SequenceGenerator(name = "ORDER_CODE_GEN", 
sequenceName = "ORDER_SEQ", 
allocationSize = 1, 
initialValue = 1)
public class OrderVO {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE,
					generator = "ORDER_CODE_GEN")
	@Column(name = "PAY_CODE")
	private Long code; 
	
	@Column(name = "CARD_NUMBER")
	private String cardNumber;
	
	@Column(name = "PAY_AMOUNT")
	private String payAmount;
	
	@Column(name = "PAY_DATE")
	private String payDate;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "USER_CODE")
	private UserVO user;
	
}
