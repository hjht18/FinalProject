package com.example.demo.user.form;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SocialLoginForm {
	
	private String nickname;
	private String profile_image;
	private String name;
}
