package com.example.demo.user.form;

import org.springframework.web.multipart.MultipartFile;

import com.example.demo.user.UserVO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserForm {

	private Long code;
	private String id;
	private String name;
	private String password;
	private String birth;
	private String phoneNum;
	private String zipCode;
	private String basicAddress;
	private String detailAddress;
	private String image;
	private MultipartFile imageFile;
	
	public UserForm() {}
	
	public UserForm(UserVO vo) {
		code = vo.getCode();
		id = vo.getId();
		name = vo.getName();
		password = vo.getPassword();
		phoneNum = vo.getPhoneNum();
		zipCode = vo.getZipCode();
		basicAddress = vo.getBasicAddress();
		detailAddress = vo.getDetailAddress();
		image = vo.getImage();
	}
}
