package com.example.demo.admin;

public class AdminVO {

}
