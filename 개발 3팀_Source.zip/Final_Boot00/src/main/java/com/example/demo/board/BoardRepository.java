package com.example.demo.board;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.EntityGraph.EntityGraphType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.free.FreeVO;

@Repository
public interface BoardRepository extends JpaRepository<BoardVO, Long>{
	
	public BoardVO save(BoardVO vo);
	
	@EntityGraph(attributePaths = {"user"}, type = EntityGraphType.LOAD)
	public BoardVO findByCode(Long code);
	
	@EntityGraph(attributePaths = {"user"}, type = EntityGraphType.LOAD)
	public Page<BoardVO> findByTitleContaining(Pageable pageable, String title);
	
	@EntityGraph(attributePaths = {"user"}, type = EntityGraphType.LOAD)
	public Page<BoardVO> findByContentContaining(Pageable pageable, String content);
	
	@EntityGraph(attributePaths = {"user"}, type = EntityGraphType.LOAD)
	public Page<BoardVO> findByLocationContaining(Pageable pageable, String location);
	
	@EntityGraph(attributePaths = {"user"}, type = EntityGraphType.LOAD)
	public Page<BoardVO> findByUserNameContaining(Pageable pageable, String name);
	
	@EntityGraph(attributePaths = {"user"}, type = EntityGraphType.LOAD)
	public Page<BoardVO> findAll(Pageable pageable);
	
	public void delete(BoardVO vo);
}
