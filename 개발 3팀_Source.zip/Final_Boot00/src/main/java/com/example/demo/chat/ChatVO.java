package com.example.demo.chat;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "CHAT")
@SequenceGenerator(name = "CHAT_SEQ_GEN", sequenceName = "CHAT_SEQ", allocationSize = 1, initialValue = 1)
public class ChatVO {
	
	@Id
	@GeneratedValue(generator = "CHAT_SEQ_GEN", strategy = GenerationType.SEQUENCE)
	private Long id;
	
	@Column(name = "CHAT_ROOM")
	private int room;
	
	@Column(name = "CHAT_TIME")
	private String time;
	
	@Column(name = "CHAT_MESSAGE")
	private String message;
	
	@Column(name = "CHAT_FROM")
	private String from;
	
	@Column(name = "CHAT_TO")
	private String to;
}
