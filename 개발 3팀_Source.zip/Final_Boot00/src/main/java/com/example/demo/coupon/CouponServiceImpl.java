package com.example.demo.coupon;

import java.util.List;

import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class CouponServiceImpl implements CouponService {

	private final CouponDAO dao;
	
	@Override
	public void save(CouponVO vo) {
		dao.save(vo);
	}

	@Override
	public CouponVO findOne(Long code) {
		return dao.findOne(code);
	}

	@Override
	public List<CouponVO> findAll() {
		return dao.findAll();
	}

	@Override
	public void update(CouponVO vo, Long code) {
		CouponVO coupon = dao.findOne(code);
		coupon.setLocation(vo.getLocation());
		coupon.setOrder(vo.getOrder());
		coupon.setPrice(vo.getPrice());
		coupon.setStore(vo.getStore());
		coupon.setUser(vo.getUser());
		
	}

	@Override
	public void delete(Long code) {
		CouponVO coupon = dao.findOne(code);
		dao.delete(coupon);
	}

	
}
