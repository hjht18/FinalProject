package com.example.demo.coupon;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
public class CouponController {

	private final CouponService service;
	
	@GetMapping("/coupon/{code}")
	public CouponVO findOne(Long code) {
		return service.findOne(code);
	}
	
	@GetMapping("/coupons")
	public List<CouponVO> findAll() {
		return service.findAll();
	}
	
	@PostMapping("/coupon")
	public void save(CouponVO vo) {
		service.save(vo);
	}
	
	@PatchMapping("/coupon/{code}")
	public void update(Long code, CouponVO vo) {
		service.update(vo, code);
	}
	
	@DeleteMapping("/coupon/{code}")
	public void delete(Long code) {
		service.delete(code);
	}
}
