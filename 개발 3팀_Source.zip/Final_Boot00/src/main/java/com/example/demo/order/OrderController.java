package com.example.demo.order;

import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@CrossOrigin
public class OrderController {
	
	private final OrderService service;
	
	@PostMapping("/order")
	public void save(@RequestBody OrderVO vo) {
		service.save(vo);
	}
	
	@GetMapping("/order/{code}")
	public OrderVO findOne(@PathVariable Long code) {
		return service.findOne(code);
	}
	
	@GetMapping("/orders")
	public List<OrderVO> findList() {
		return service.findList();
	}
	
	@DeleteMapping("/order/{code}")
	public void delete(@PathVariable Long code) {
		service.delete(code);
	}
}
