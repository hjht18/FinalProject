package com.example.demo.board;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.example.demo.user.UserVO;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "BOARD")
@SequenceGenerator(name = "BOARD_CODE_GEN", 
sequenceName = "BOARD_SEQ", 
allocationSize = 1, 
initialValue = 1)
public class BoardVO {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE,
					generator = "BOARD_CODE_GEN")
	@Column(name = "BOARD_CODE")
	private Long code; 
	
	@Column(name = "BOARD_TITLE")
	private String title;
	
	@Column(name = "BOARD_DATE")
	private String date;
	
	@Column(name = "BOARD_CONTENT", length = 3000)
	private String content;
	
	@Column(name = "LOCATION")
	private String location;
	
	@Column(name = "BOARD_IMAGE")
	private String image;
	
	@Column(name = "TRAVEL_STARTDATE")
	private LocalDateTime travelStartDate;
	
	@Column(name = "VIEW_COUNT")
	private int viewCount;
	
	@Column(name = "TRAVEL_ENDDATE")
	private LocalDateTime travelEndDate;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "USER_CODE")
	private UserVO user;
	
}
