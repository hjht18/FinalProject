package com.example.demo.board;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class BoardServiceImpl implements BoardService {
	
//	private final BoardDAO dao;
	private final BoardRepository dao;

	@Override
	@Transactional
	public void save(BoardVO vo) {
		dao.save(vo);
	}

	@Override
	public BoardVO findOne(Long code) {
//		return dao.findOne(code);
		return dao.findByCode(code);
	}

	@Override
	public List<BoardVO> findList(int page) {
		Page<BoardVO> boardPage = dao.findAll(PageRequest.of(page, 10, Sort.by("code").descending()));
		List<BoardVO> boards = boardPage.getContent();
//		return dao.findList();
		return boards;
	}
	
	@Override
	public List<BoardVO> findByTitleContaining(int page, String title) {
		Page<BoardVO> boardPage = dao.findByTitleContaining(PageRequest.of(page, 10, Sort.by("code").descending()), title);
		List<BoardVO> boards = boardPage.getContent();
		return boards;
	}
	
	@Override
	public List<BoardVO> findByContentContaining(int page, String content) {
		Page<BoardVO> boardPage = dao.findByContentContaining(PageRequest.of(page, 10, Sort.by("code").descending()), content);
		List<BoardVO> boards = boardPage.getContent();
		return boards;
	}
	
	@Override
	public List<BoardVO> findByLocationContaining(int page, String location) {
		Page<BoardVO> boardPage = dao.findByLocationContaining(PageRequest.of(page, 10, Sort.by("code").descending()), location);
		List<BoardVO> boards = boardPage.getContent();
		return boards;
	}
	
	@Override
	public List<BoardVO> findByUserNameContaining(int page, String name) {
		Page<BoardVO> boardPage = dao.findByUserNameContaining(PageRequest.of(page, 10, Sort.by("code").descending()), name);
		List<BoardVO> boards = boardPage.getContent();
		return boards;
	}
	
	@Override
	public Long getTotalNum() {
		Page<BoardVO> boardPage = dao.findAll(PageRequest.of(1, 10, Sort.by("code").descending()));
		return boardPage.getTotalElements();
	}

	@Override
	@Transactional
	public void update(Long code, BoardVO vo) {
//		BoardVO board = dao.findOne(code);
		BoardVO board = dao.findByCode(code);
		board.setTitle(vo.getTitle());
		board.setDate(vo.getDate());
		board.setContent(vo.getContent());
		board.setImage(vo.getImage());
		board.setTravelStartDate(vo.getTravelStartDate());
		board.setTravelEndDate(vo.getTravelEndDate());
		board.setUser(vo.getUser());
		board.setViewCount(vo.getViewCount());
		board.setLocation(vo.getLocation());
	}

	@Override
	@Transactional
	public void delete(Long code) {
//		BoardVO board = dao.findOne(code);
		BoardVO board = dao.findByCode(code);
		dao.delete(board);
	}

	
}
