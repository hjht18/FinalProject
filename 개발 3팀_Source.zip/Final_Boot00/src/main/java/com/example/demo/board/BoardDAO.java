package com.example.demo.board;

import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.stereotype.Repository;

import lombok.RequiredArgsConstructor;

@Repository
@RequiredArgsConstructor
public class BoardDAO {
	
	private final EntityManager em;
	
	// 게시글 저장
	public void save(BoardVO vo) {
		em.persist(vo);
	}
	
	// 게시글 조회
	public BoardVO findOne(Long code) {
		String sql = "select b from BoardVO b join fetch b.user u where b.code =: code";
		return em.createQuery(sql, BoardVO.class).setParameter("code",code).getResultList().get(0);
	}
	
	// 게시글 목록 조회
	public List<BoardVO> findList() {
		String sql = "select b from BoardVO b join fetch b.user u";
		return em.createQuery(sql, BoardVO.class).setMaxResults(10).getResultList();
	}
	
	// 게시글 삭제
	public void delete(BoardVO vo) {
		em.remove(vo);
	}
}
