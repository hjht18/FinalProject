package com.example.demo.free;

import java.util.List;

public interface FreeService {

	// 게시글 저장
	void save(FreeVO vo);

	// 게시글 조회
	FreeVO findOne(Long code);

	// 게시글 목록 조회
	List<FreeVO> findList(int page);

	// 게시글 검색
	List<FreeVO> findByTitleContaining(int page, String title);

	// 게시글 검색
	List<FreeVO> findByContentContaining(int page, String content);

	// 게시글 검색
	List<FreeVO> findByUserNameContaining(int page, String name);

	// 게시글 총 개수 조회
	Long getTotalNum();

	// 게시글 수정
	void update(Long code, FreeVO vo);

	// 게시글 삭제
	void delete(Long code);
}
