package com.example.demo.free;

public class FreeDAO {

}
