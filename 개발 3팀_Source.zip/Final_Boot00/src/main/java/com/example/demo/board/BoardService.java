package com.example.demo.board;

import java.util.List;

import org.springframework.data.domain.Pageable;

import com.example.demo.free.FreeVO;

public interface BoardService {

	// 게시글 저장
	void save(BoardVO vo);

	// 게시글 조회
	BoardVO findOne(Long code);

	// 게시글 목록 조회
	List<BoardVO> findList(int page);

	// 게시글 검색
	List<BoardVO> findByTitleContaining(int page, String title);

	// 게시글 검색
	List<BoardVO> findByContentContaining(int page, String content);

	// 게시글 검색
	List<BoardVO> findByLocationContaining(int page, String location);

	// 게시글 검색
	List<BoardVO> findByUserNameContaining(int page, String name);

	// 게시글 총 개수 조회
	Long getTotalNum();

	// 게시글 수정
	void update(Long code, BoardVO vo);

	// 게시글 삭제
	void delete(Long code);
}
