package com.example.demo.free;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class FreeServiceImpl implements FreeService {

	private final FreeRepository dao;
	
	@Override
	@Transactional
	public void save(FreeVO vo) {
		dao.save(vo);
	}

	@Override
	public FreeVO findOne(Long code) {
		return dao.findByCode(code);
	}

	@Override
	public List<FreeVO> findList(int page) {
		Page<FreeVO> freePage = dao.findAll(PageRequest.of(page, 10, Sort.by("code").descending()));
		List<FreeVO> frees = freePage.getContent();
		return frees;
	}

	@Override
	public List<FreeVO> findByTitleContaining(int page, String title) {
		Page<FreeVO> freePage = dao.findByTitleContaining(PageRequest.of(page, 10, Sort.by("code").descending()), title);
		List<FreeVO> frees = freePage.getContent();
		return frees;
	}
	
	@Override
	public List<FreeVO> findByContentContaining(int page, String content) {
		Page<FreeVO> freePage = dao.findByContentContaining(PageRequest.of(page, 10, Sort.by("code").descending()), content);
		List<FreeVO> frees = freePage.getContent();
		return frees;
	}
	
	@Override
	public List<FreeVO> findByUserNameContaining(int page, String name) {
		Page<FreeVO> freePage = dao.findByUserNameContaining(PageRequest.of(page, 10, Sort.by("code").descending()), name);
		List<FreeVO> frees = freePage.getContent();
		return frees;
	}

	@Override
	public Long getTotalNum() {
		Page<FreeVO> boardPage = dao.findAll(PageRequest.of(1, 10, Sort.by("code").descending()));
		return boardPage.getTotalElements();
	}

	@Override
	@Transactional
	public void update(Long code, FreeVO vo) {
		FreeVO board = dao.findByCode(code);
		board.setTitle(vo.getTitle());
		board.setDate(vo.getDate());
		board.setContent(vo.getContent());
		board.setImage(vo.getImage());
		board.setUser(vo.getUser());
		board.setViewCount(vo.getViewCount());
	}

	@Override
	@Transactional
	public void delete(Long code) {
		FreeVO board = dao.findByCode(code);
		dao.delete(board);
	}

	
}
