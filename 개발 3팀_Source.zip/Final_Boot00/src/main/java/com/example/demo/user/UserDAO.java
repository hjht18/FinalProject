package com.example.demo.user;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;

import org.springframework.stereotype.Repository;

import com.example.demo.user.form.UserForm;

import lombok.RequiredArgsConstructor;

@Repository
@RequiredArgsConstructor
public class UserDAO {

	private final EntityManager em;
	
	public void save(UserVO vo) {
		em.persist(vo);
	}
	
	public UserVO findOne(Long code) {
		return em.find(UserVO.class, code);
	}
	
	public List<UserVO> findAll(){
		return em.createQuery("select u from UserVO u", UserVO.class).getResultList();
	}
	
	public void delete(UserVO vo) {
		em.remove(vo);
	}
	
	public Optional<UserVO> findByLoginId(String id){
		return findAll()
				.stream()
				.filter(u -> u.getId().equals(id)).findFirst();
	}
}
