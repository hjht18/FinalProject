package com.example.demo.order;

import java.util.List;

public interface OrderService {
	
	void save(OrderVO vo);
	
	OrderVO findOne(Long code);
	
	List<OrderVO> findList();
	
	void delete(Long code);
}
