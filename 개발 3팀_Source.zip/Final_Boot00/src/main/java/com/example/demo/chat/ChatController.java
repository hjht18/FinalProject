package com.example.demo.chat;

import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@CrossOrigin
public class ChatController {

	private final ChatService service;
	
	// 채팅 목록 조회
	@GetMapping("/chatList/{room}")
	public List<ChatVO> chatList(@PathVariable int room){
		return service.chatList(room);
	}
	
	// 최근 채팅 조회
	@GetMapping("/latestChat/{room}")
	public ChatVO latestChat(@PathVariable int room) {
		return service.latestChat(room);
	}
	
	// 채팅 저장
	@PostMapping("/chatSave")
	public void save(@RequestBody ChatVO vo) {
		service.save(vo);
	}
	
	// 메타데이터
	@GetMapping("/chatMetaData")
	public List<ChatVO> chatMetaData(){
		return service.chatMetaData();
	}
	
	/* UUID를 이용하여 room번호 설정 
	 * from : 자기 자신 (author)
	 * to : 상대방(뭐로 설정할까?)
	 * 
	 * */
}
