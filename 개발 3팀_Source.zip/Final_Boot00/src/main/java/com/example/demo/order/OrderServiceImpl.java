package com.example.demo.order;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class OrderServiceImpl implements OrderService {

	private final OrderRepository dao;

	@Override
	@Transactional
	public void save(OrderVO vo) {
		dao.save(vo);
		
	}

	@Override
	public OrderVO findOne(Long code) {
		return dao.findByCode(code);
	}

	@Override
	public List<OrderVO> findList() {
		return dao.findAll();
	}

	@Override
	@Transactional
	public void delete(Long code) {
		dao.delete(dao.findByCode(code));
	}
	
	
}
