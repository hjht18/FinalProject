package com.example.demo.user;

import java.util.List;

public interface UserService {
	
	public void save(UserVO vo);
	
	public List<UserVO> findAll();
	
	public void update(Long code, UserVO vo);
	
	public UserVO findOne(Long code);
	
	public void delete(Long code);
	
	public UserVO login(String id, String password);
}
