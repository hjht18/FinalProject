package com.example.demo.user;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<UserVO, Long>{
	
	public UserVO save(UserVO vo);
	
	public UserVO findByCode(Long code);
	
	public Optional<UserVO> findById(String id);
	
	public List<UserVO> findAll();
	
	public void delete(UserVO vo);
	
}
