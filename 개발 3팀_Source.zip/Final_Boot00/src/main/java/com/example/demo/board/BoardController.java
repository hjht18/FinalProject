package com.example.demo.board;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@CrossOrigin
public class BoardController {

	private final BoardService service;

	@Value("${boardFile.dir}")
	private String fileDir;

	// 게시판 저장
	@PostMapping("/board")
	public void save(@RequestBody BoardVO vo) {
		service.save(vo);
	}

	// 게시판 조회
	@GetMapping("/board/{code}")
	public BoardVO findOne(@PathVariable Long code) {
		return service.findOne(code);
	}

	// 게시글 총 개수
	@GetMapping("/getTotalNum")
	public Long getTotalNum() {
		return service.getTotalNum();
	}

	// 게시판 목록 조회
	@GetMapping("/boards/{page}")
	public List<BoardVO> findList(@PathVariable int page) {
		List<BoardVO> boardList = service.findList(page - 1);
		return boardList;
	}

	// 게시판 검색
	@GetMapping("/boards/title/{page}/{title}")
	public List<BoardVO> findByTitleContaining(@PathVariable int page, @PathVariable String title) {
		List<BoardVO> boardList = service.findByTitleContaining(page - 1, title);
		return boardList;
	}

	// 게시판 검색
	@GetMapping("/boards/content/{page}/{content}")
	public List<BoardVO> findByContentContaining(@PathVariable int page, @PathVariable String content) {
		List<BoardVO> boardList = service.findByContentContaining(page - 1, content);
		return boardList;
	}

	// 게시판 검색
	@GetMapping("/boards/location/{page}/{location}")
	public List<BoardVO> findByLocationContaining(@PathVariable int page, @PathVariable String location) {
		List<BoardVO> boardList = service.findByLocationContaining(page - 1, location);
		return boardList;
	}

	// 게시판 검색
	@GetMapping("/boards/name/{page}/{name}")
	public List<BoardVO> findByUserNameContaining(@PathVariable int page, @PathVariable String name) {
		List<BoardVO> boardList = service.findByUserNameContaining(page - 1, name);
		return boardList;
	}

	// 게시판 수정
	@PatchMapping("/board/{code}")
	public void update(@PathVariable Long code, @RequestBody BoardVO vo) {
		service.update(code, vo);
	}

	// 게시판 삭제
	@DeleteMapping("/board/{code}")
	public void delete(@PathVariable Long code) {
		service.delete(code);
	}

	// 이미지 업로드
	@PostMapping("/boardImage")
	public void imageDownload(@RequestBody MultipartFile file) throws IllegalStateException, IOException {
		File newFile = new File(fileDir + "/" + file.getOriginalFilename());
		if (!newFile.exists()) {
			newFile.mkdirs();
		}

		if (!file.isEmpty()) {
			file.transferTo(newFile);
		}

		System.out.println(file);
	}
}
