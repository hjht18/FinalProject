import axios from 'axios';
import qs from 'qs';
import { useEffect, useState } from 'react';
import { connect } from 'react-redux';
import { useHistory } from 'react-router';

const NaverCallback = (props) => {

    const history = useHistory();
    const access_token = window.location.href.split('=')[1].split('&')[0];

    const [name, setName] = useState('');
    const [nickname, setNickname] = useState('');
    const [email, setEmail] = useState('');
    const [data, setData] = useState({});

    const getProfile = async () => {
        try {
            await axios.post('http://localhost:8080/getToken', access_token)
            .then((res) => {
                setName(res.data.response.name);
                setNickname(res.data.response.nickname);
                setEmail(res.data.response.email);
                setData(res.data);
                props.dispatch({type : '로그인'})
              props.dispatch({type : '로그인유저', payload : {name : res.data.response.name}});
            });
        } catch (err) {
          console.log(err);
        }
      };

    useEffect(() => {
            getProfile();
            // window.close()
            
            history.push("/");
        }, []);


    // console.log(window.location.href.split('code=')[1].split('&state=')[0]);

    // const getToken = async () => {
    //     const payload = qs.stringify({
    //         grant_type : grant_type,
    //         client_id : client_id,
    //         client_secret : client_secret,
    //         code : code,
    //         state : state
    //     });

    //     try {
    //         await axios.post(
    //             "https://nid.naver.com/oauth2.0/token",
    //             payload
    //         ).then((res) => {
    //             axios.post("http://localhost:8080/getToken", res.access_token)
    //         })
    //     } catch(err){
    //         console.log(err);
    //     }
    // };

    // useEffect(() => {
    //     const headers = {
    //         'Accept': '*/*',
    //         'Authorization': `Bearer ${access_token}`
    //     }
    //     axios.get('http://openapi.naver.com/v1/nid/me', headers)
    //     .then((res) => alert(res.data.resultcode))
    //     .catch(() => alert('실패'));
    // }, []);

    return(
        <div>
            엑세스토큰 : {access_token} <br/>
            이름 : {name} <br/>
            아이디 : {nickname} <br/>
            이메일 : {email} 
        </div>
    );
}

function props화함수(state) {
    return {
      유저: state.userReducer,
      로그인상태: state.loginReducer,
    };
  }

export default connect(props화함수)(NaverCallback);

