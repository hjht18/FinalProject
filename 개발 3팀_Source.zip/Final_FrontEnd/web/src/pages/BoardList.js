import React, { useState, useEffect } from "react";
import Navibar from "./Navibar";
import axios from "axios";
import { Link, useHistory } from "react-router-dom";
import ModalWindow from "../components/ModalWindow";
import ModalBtn from "../components/ModalBtn";
import { connect } from "react-redux";
import Footer from "../components/Footer";

const BoardList = (props) => {
  const [페이지, 페이지변경] = useState(1);
  const [페이지개수, 페이지개수변경] = useState(0);
  const [검색어, 검색어변경] = useState("");
  const [검색조건, 검색조건변경] = useState('');

  useEffect(() => {
    axios.get(`http://localhost:8080/boards/${페이지}`).then((res) => {
      props.dispatch({ type: "게시글목록변경", payload: res.data });
    });
  }, [페이지]);

  let history = useHistory();

  useEffect(() => {
    axios.get('http://localhost:8080/getTotalNum').then((res) => {
      페이지개수변경(Math.floor((res.data / 10) + 1));
      console.log(페이지개수);
    })
  },[페이지개수]);

  const 검색 = () => {
    axios
      .get(`http://localhost:8080/boards/title/${페이지}/${검색어}`)
      .then((res) => {
        페이지개수변경(Math.floor((res.data / 10) + 1));
        props.dispatch({ type: "게시글목록변경", payload: res.data });
      });
  };

  const 내용검색 = () => {
    axios
      .get(`http://localhost:8080/boards/content/${페이지}/${검색어}`)
      .then((res) => {
        페이지개수변경(Math.floor((res.data / 10) + 1)); 
        props.dispatch({ type: "게시글목록변경", payload: res.data });
      });
  };

  const 지역검색 = () => {
    axios
      .get(`http://localhost:8080/boards/location/${페이지}/${검색어}`)
      .then((res) => {
        페이지개수변경(Math.floor((res.data / 10) + 1));
        props.dispatch({ type: "게시글목록변경", payload: res.data });
      });
  };

  const 이름검색 = () => {
    axios
      .get(`http://localhost:8080/boards/name/${페이지}/${검색어}`)
      .then((res) => {
        페이지개수변경(Math.floor((res.data / 10) + 1));
        props.dispatch({ type: "게시글목록변경", payload: res.data });
      });
  };

  return (
    <div>
      <Navibar />
      {/* 게시판 목록 시작 */}​
      <div className="container-sm pt-5">
        ​
        <table className="table table-hover">
          <thead className="table-light">
            <tr>
              <th scope="col" className="text-left">
                번호
              </th>
              <th scope="col" className="text-left">
                지역
              </th>
              <th scope="col" className="text-left">
                제목
              </th>
              <th scope="col" className="text-center">
                작성자
              </th>
              <th scope="col" className="text-center">
                작성날짜
              </th>
              <th scope="col" className="text-center">
                조회수
              </th>
            </tr>
          </thead>
          <tbody>
            {props.게시글목록.map(function (게시글, 인덱스) {
              return (
                <>
                  <Board
                    번호={게시글.code}
                    지역={게시글.location}
                    제목={게시글.title}
                    작성자={게시글.user.name}
                    작성일={게시글.date}
                    조회수={게시글.viewCount}
                    이미지={게시글.user.image}
                    onClick={() => {
                      axios.patch(
                        `http://localhost:8080/board/${게시글.code}`,
                        { ...게시글, viewCount: 게시글.viewCount + 1 }
                      );
                      history.push(`/boardDetail/${게시글.code}`);
                    }}
                  />
                  {/* {
                  게시글스위치
                  ? <ModalWindow 
                  image="https://t3.daumcdn.net/thumb/R720x0.fjpg/?fname=http://t1.daumcdn.net/brunch/service/user/cnoC/image/MVXKXCbEwk6GIO7bzjVpafxjSaA.jpg"
                  code = {게시글.code}
                  제목 = {게시글.title}
                  내용 = {게시글.content} />
                  : null  
                } */}
                </>
              );
            })}
            {/* 테스트용 tr 끝 (적용시 삭제)*/}
          </tbody>
        </table>
        <div className="d-grid gap-2 d-md-flex justify-content-md-end">
          <Link
            to="/boardWrite"
            className="btn-solid-sm"
            style={{ textDecoration: "none" }}
          >
            글쓰기
          </Link>
        </div>

        <div className="container w-50">
          <div className="d-flex align-items-center">
            <select
              id="searchType"
              className="form-select form-select-sm"
              aria-label="Default select example"
              style={{ width: "120px" }}
            >
              <option value="title">제목</option>
              <option value="content">내용</option>
              <option value="title_content">지역</option>
              <option value="writer">작성자</option>
            </select>
            <input
              type="text"
              onChange={(e) => {
                검색어변경(e.target.value);
              }}
              name="keyword"
              className="form-control form-control-sm"
              style={{ width: "500px" }}
            />
            <button
              id="searchBtn"
              className="btn btn-primary"
              style={{
                textDecoration: "none",
                marginLeft: "15px",
                borderColor: "#FF5574",
                backgroundColor: "#FF5574",
                whiteSpace: "nowrap",
              }}
              onClick={() => {
                let options = document.getElementById("searchType").options;
                if (options[0].selected) {
                  검색조건변경('제목');
                  검색();
                  console.log("제목검색");
                } else if (options[1].selected) {
                  검색조건변경('내용');
                  내용검색();
                  console.log("내용검색");
                } else if (options[2].selected) {
                  검색조건변경('지역');
                  지역검색();
                  console.log("지역검색");
                } else if (options[3].selected) {
                  검색조건변경('이름');
                  이름검색();
                  console.log("이름검색");
                }
                if (검색어 == "") {
                  axios
                    .get(`http://localhost:8080/boards/${페이지}`)
                    .then((res) => {
                      페이지개수변경(Math.floor((res.data / 10) + 1));
                      props.dispatch({
                        type: "게시글목록변경",
                        payload: res.data,
                      });
                    });
                }
              }}
            >
              검색
            </button>
          </div>
        </div>
        ​
        <nav aria-label="Page navigation example">
          <ul
            className="pagination justify-content-center"
            style={{ color: "#ff5574" }}
          >
            <li className="page-item">
              <a className="page-link" href="#" aria-label="Previous">
                <span aria-hidden="true" style={{ color: "#ff5574" }}>
                  «
                </span>
              </a>
            </li>
            <PageBox 페이지변경={페이지변경} 페이지개수={페이지개수}/>
            <li className="page-item">
              <a className="page-link" href="#" aria-label="Next">
                <span aria-hidden="true" style={{ color: "#ff5574" }}>
                  »
                </span>
              </a>
            </li>
          </ul>
        </nav>
        ​{/* 게시판 리스트 끝*/}​ ​
      </div>
      <Footer />
      {/* end of footer */}
      {/* Back To Top Button */}
      <button onclick="topFunction()" id="myBtn">
        <img src="assets/images/up-arrow.png" alt="alternative" />
      </button>
      {/* end of back to top button */}
    </div>
  );
};

const Board = (props) => {
  // timestamp 날짜변환
  function unixToDateFormatter(date) {
    // yyyy-mm-dd hh:mm:ss.s
    var dateFormatt = new Date(date);
    var year = dateFormatt.getFullYear();
    var month = 0;
    if (dateFormatt.getUTCMonth() < 9) {
      month = "0" + (dateFormatt.getUTCMonth() + 1).toString();
    } else {
      month = dateFormatt.getUTCMonth() + 1;
    }
    var day =
      (dateFormatt.getUTCDate() < 10 ? "0" : "") + dateFormatt.getUTCDate();

    var hour = 0;
    if (dateFormatt.getHours() < 10) {
      hour = "0" + dateFormatt.getHours().toString();
    } else {
      hour = dateFormatt.getHours();
    }

    var minute = 0;
    if (dateFormatt.getMinutes() < 10) {
      minute = "0" + dateFormatt.getMinutes().toString();
    } else {
      minute = dateFormatt.getMinutes();
    }

    var fullDateFormatt;
    fullDateFormatt =
      year + "-" + month + "-" + day + " " + hour + ":" + minute;
    console.log("DateFormatt : " + fullDateFormatt);
    return fullDateFormatt;
  }

  const 작성일 = unixToDateFormatter(props.작성일);

  let 배경색 = "black";
  switch (props.지역) {
    case "서울":
      배경색 = "#FF9999";
      break;
    case "인천":
      배경색 = "#ED6663";
      break;
    case "대전":
      배경색 = "#A2D2FF";
      break;
    case "대구":
      배경색 = "#396EB0";
      break;
    case "광주":
      배경색 = "#FC997C";
      break;
    case "부산":
      배경색 = "#BFA2DB";
      break;
    case "울산":
      배경색 = "#FF87CA";
      break;
    case "경기":
      배경색 = "#A2CDCD";
      break;
    case "강원":
      배경색 = "#F5C6A5";
      break;
      case "제주":
        배경색 = "#FF7777";
        break;
  }

  return (
    <tr
      onClick={props.onClick}
      data-bs-toggle="modal"
      data-bs-target="#staticBackdrop"
    >
      <th scope="row" className="text-left">
        {props.번호}
      </th>
      <td className="text-center">
        <div
          style={{
            backgroundColor: 배경색,
            width: "50px",
            borderRadius: "10px",
            color: "#fff",
          }}
        >
          {props.지역}
        </div>
      </td>
      <td className="text-left">{props.제목}</td>
      <td className="text-center">
        <img src={`/assets/userimage/${props.이미지}`} style={{width : "30px", height : "30px", borderRadius : "15px", border : "1.5px solid black"}}/>&nbsp;&nbsp;{props.작성자}</td>
      <td className="text-center">{작성일}</td>
      <td className="text-center">{props.조회수}</td>
    </tr>
  );
};

function props화함수(state) {
  return {
    유저: state.userReducer,
    로그인상태: state.loginReducer,
    게시글: state.boardReducer,
    게시글목록: state.boardListReducer,
  };
}

const PageBox = (props) => {
  const array = [];
  for(let i = 0 ; i < props.페이지개수 ; i++){
    array.push(
    <li className="page-item">
    <strong
      className="page-link"
      style={{ color: "#ff5574" }}
      onClick={() => {
        props.페이지변경(i + 1);
      }}
    >
      {i + 1}
    </strong>
  </li>);
  }
  return array;
}

export default connect(props화함수)(BoardList);
