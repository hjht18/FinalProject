import React from 'react'
import {BrowserRouter as Router, Switch, Route} from 'react-router-dom'
import BoardList from './BoardList'
import BoardWriteForm from './BoardWriteForm'
import PassMain from './PassMain'
import Home from './Home'
import Login from './Login'
import SignUp from './SignUp'
import SingUpSuccess from './SignUpSuccess'
import PassDetail_ChungCheong from './PassDetail_ChungCheong'
import PassDetail_GangWon from './PassDetail_GangWon'
import PassDetail_HoNam from './PassDetail_HoNam'
import PassDetail_Jeju from './PassDetail_Jeju'
import PassDetail_Seoul from './PassDetail_Seoul'
import PassDetail_YeongNam from './PassDetail_YeongNam'
import NaverCallback from './NaverCallback'
import Auth from './Auth'
import Profile from './Profile'
import Modify from './Modify'
import Chat from '../Chat'
import Join from '../Join'
import BoardDetail from './BoardDetail'
import BoardModifyForm from './BoardModifyForm'
import JoinAtNav from '../JoinAtNav'
import FreeBoardList from './FreeBoardList'
import FreeBoardWriteForm from './FreeBoardWriteForm'
import FreeBoardDetail from './FreeBoardDetail'
import FreeBoardModifyForm from './FreeBoardModifyForm'

const RouterPage = () => {

    return (
        <div>
            <Router>
                <Switch>
                    <Route path="/" exact component={Home}/>
                    <Route path="/login" component={Login}/>
                    <Route path="/signUp" component={SignUp}/>
                    <Route path="/signUpSuccess" component={SingUpSuccess}/>
                    <Route path="/pass" exact component={PassMain}/>
                    <Route path="/boardWrite" component={BoardWriteForm}/>
                    <Route path="/boardModify/:code" component={BoardModifyForm}/>
                    <Route path="/boardList" component={BoardList}/>
                    <Route path="/pass/chungcheong" exact component={PassDetail_ChungCheong}/>
                    <Route path="/pass/gangwon" exact component={PassDetail_GangWon}/>
                    <Route path="/pass/honam" exact component={PassDetail_HoNam}/>
                    <Route path="/pass/jeju" exact component={PassDetail_Jeju}/>
                    <Route path="/pass/seoul" exact component={PassDetail_Seoul}/>
                    <Route path="/pass/yeongnam" exact component={PassDetail_YeongNam}/>
                    <Route path="/callback_management" component={NaverCallback}/>
                    <Route path="/oauth/kakao/callback" component={Auth}/>
                    <Route path="/profile" component={Profile}/>
                    <Route path="/modify" component={Modify} />
                    <Route path="/chat" component={Chat} />
                    <Route path="/joinChat" component={Join}/>
                    <Route path="/joinChatAtNav" component={JoinAtNav}/>
                    <Route path="/boardDetail/:code" component={BoardDetail}/>
                    <Route path="/freeBoardList" component={FreeBoardList}/>
                    <Route path="/freeBoardWrite" component={FreeBoardWriteForm}/>
                    <Route path="/freeBoardDetail/:code" component={FreeBoardDetail}/>
                    <Route path="/freeBoardModify/:code" component={FreeBoardModifyForm}/>
                    <Route path="/oauth/kakao/callback" component={Auth}/>

                </Switch>
            </Router>
        </div>
    )

}

export default RouterPage;
