/* eslint-disable */
/* eslint-disable-next-line */

import axios from "axios";
import React, { useEffect, useState, useRef } from "react";
import { Link, useHistory, useLocation } from "react-router-dom";
import { connect } from "react-redux";
import Navibar from "./Navibar";
import Footer from "../components/Footer";
import NaverLogin from "react-login-by-naver";

import Auth from "../Auth";
import { Route } from "react-router";

const Login = (props) => {
  const [user, setUser] = useState({});
  const [id, setId] = useState("");
  const [pw, setPw] = useState("");

  const history = useHistory();

  useEffect(() => {
    const loginForm = { id: id, password: pw };
    setUser(loginForm);
  }, [id, pw]);

  const 로그인 = () => {
    axios.post("http://localhost:8080/login", user).then((res) => {
      console.log(res.data.name);

      if (user.id == "" || user.pw == "") {
        alert("아이디나 비밀번호를 입력해주세요");
      } else {
        if (res.data.name == undefined) {
          alert("아이디 또는 비밀번호가 존재하지 않습니다");
        } else {
          alert("로그인에 성공하였습니다");
          props.dispatch({ type: "로그인" });
          props.dispatch({ type: "로그인유저", payload: res.data });
          history.push("/");
        }
      }
    });
  };

  // ######################################### //

  // const NAVER_CLIENT_KEY = "UyCQydLcNsrRyZ2MHxCf"
  // const NAVER_REDIRECT_URI = "http://localhost:3000/callback_management"
  // const NAVER_AUTH_URL = `https://nid.naver.com/oauth2.0/authorize?response_type=code&client_id=${NAVER_CLIENT_KEY}&redirect_uri=${NAVER_REDIRECT_URI}&state=state`;

  // ######################################### //

  // 카카오 로그인 로직

  const REST_API_KEY = "69b766bff50d4561c49c9459c0dd5e3b";
  const REDIRECT_URI = "http://localhost:3000/oauth/kakao/callback";
  const KAKAO_AUTH_URL = `https://kauth.kakao.com/oauth/authorize?client_id=${REST_API_KEY}&redirect_uri=${REDIRECT_URI}&response_type=code`;


  return (
    <div>
      {/* 로 그 인 */}
      <Navibar />
      {/* Contact */}
      <div id="contact" className="form-1">
        <div className="container">
          <div className="row">
            <div className="col-lg-12">
              <h2 className="h2-heading">간편가입 / 로그인</h2>
              <p className="p-heading">위트래블을 통해 벗을 만나보세요!</p>
              <br />
              <br />
            </div>{" "}
            {/* end of col */}
          </div>{" "}
          {/* end of row */}
          <div className="row">
            <div className="col-lg-10 offset-lg-1">
              {/* Contact Form */}
              <form>
                {/* <div className="form-group">
                  <a href={NAVER_AUTH_URL}>
                    <img src="assets/images/naverloginimage.png" />
                  </a>
                </div> */}

                       <div className="form-group">
                <NaverLogin
        clientId="UyCQydLcNsrRyZ2MHxCf"
        callbackUrl="http://localhost:3000/callback_management"
        render={(props) => (
          <div onClick={props.onClick}>
            <img src="assets/images/naverloginimage.png" />
          </div>
        )}
        // onSuccess={(res) => alert(res)}
        // onFailure={() => console.log("naver login fail")}
      />
                </div>
                
                <div className="form-group">
                  <a href={KAKAO_AUTH_URL}>
                    <img
                      src="assets/images/kakao_login_medium_wide.png"
                      width="300px"
                      height="45px"
                    />
                  </a>
                  <Route path="/oauth/kakao/callback">
                    <Auth />
                  </Route>
                </div>
                {/* <p className="p-heading" style={{ fontSize: "13px" }}>
                  OR
                </p> */}
                <br />
                <div className="form-group">
                  <input
                    type="text"
                    className="form-control-input"
                    placeholder="아이디"
                    style={{ width: "300px", borderColor: "lightgray" }}
                    onChange={(e) => {
                      setId(e.target.value);
                    }}
                  />
                </div>
                <div className="form-group">
                  <input
                    type="password"
                    className="form-control-input"
                    placeholder="비밀번호"
                    style={{ width: "300px", borderColor: "lightgray" }}
                    onChange={(e) => {
                      setPw(e.target.value);
                    }}
                  />
                </div>
                <br />
                <div className="form-group">
                  <button
                    type="button"
                    className="form-control-submit-button"
                    style={{ width: "100px" }}
                    onClick={로그인}
                  >
                    로그인
                  </button>
                </div>

                <div className="form-group">
                  <Link to="/signUp">
                    <a className="nav-link" style={{ fontSize: "12px" }}>
                      위트래블이 처음이신가요?&nbsp;&nbsp;
                      <strong>회원가입 하러가기</strong>
                    </a>
                  </Link>
                </div>
              </form>
              {/* end of contact form */}
            </div>{" "}
            {/* end of col */}
          </div>{" "}
          {/* end of row */}
        </div>{" "}
        {/* end of container */}
      </div>{" "}
      {/* end of form-1 */}
      {/* end of contact */}
   
        <Footer/>
        
        {/* end of back to top button */}
    </div>
  );
};

function props화함수(state) {
  return {
    유저: state.userReducer,
    로그인상태: state.loginReducer,
  };
}



export default connect(props화함수)(Login);
