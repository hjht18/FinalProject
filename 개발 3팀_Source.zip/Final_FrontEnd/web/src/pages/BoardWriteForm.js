import React, { useState, useEffect } from "react";
import Navibar from "./Navibar";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { ko } from "date-fns/esm/locale";
import styled from "styled-components";
import { connect } from "react-redux";
import axios from "axios";
import { useHistory } from "react-router";
import { FormGroup } from "@material-ui/core";
import Footer from "../components/Footer";
import TextEditor from "../components/TextEditor";

const BoardWriteForm = (props) => {
  let history = useHistory();

  const [startDate, setStartDate] = useState(new Date());
  const [endDate, setEndDate] = useState(new Date());
  const [제목, 제목변경] = useState("");
  const [작성일, 작성일변경] = useState(new Date());
  const [내용, 내용변경] = useState("");
  const [fileImage, setFileImage] = useState("");
  const [image, setImage] = useState("");
  const [files, setFiles] = useState("");
  const [location, setLocation] = useState("");
  const [지역코드, 지역코드변경] = useState([]);

  useEffect(()=> {
    if(!props.로그인상태){
      alert('로그인이 필요한 서비스입니다');
      history.push("/login");
    }
  }, []);


  const onLoadFile = (e) => {
    const file = e.target.files;
    setFiles(file);
    setImage(file[0].name);
    setFileImage(URL.createObjectURL(e.target.files[0]));
  }

  // 파일 삭제
  const deleteFileImage = () => {
    URL.revokeObjectURL(fileImage);
    setFileImage("");
  };

  useEffect(() => {
    const 게시글폼 = {
      title: 제목,
      content: 내용,
      date: 작성일,
      image : image,
      location : location,
      travelStartDate: startDate,
      travelEndDate: endDate,
      user: {
        code: props.유저.code,
      },
    };
    props.dispatch({type : '게시글변경', payload : 게시글폼});
  }, [제목, 작성일, location, image, startDate, endDate, 내용]);


  useEffect(() => {

    const SERVICE_KEY = "nioVFR5OKV5mnLAlMVcpNHQ9eJs%2FxbeC%2Bp%2B7yqjjpLiu1bzfy3TkCbuwQ%2FzJrtol4EDz3Ark3FkdEBxstzrXBA%3D%3D";
    axios.get("http://api.visitkorea.or.kr/openapi/service/rest/KorService/areaCode?ServiceKey=" +SERVICE_KEY +"&numOfRows=10&pageNo=1&MobileOS=AND&MobileApp=appName").then((res) => {
      지역코드변경([...res.data.response.body.items.item, 11]);
    });
  }, []);

  const 게시글등록 = () => {
    transferImg();
    axios.post("http://localhost:8080/board", props.게시글).then(() => {
      alert("게시글 등록 완료");
      history.push("/boardList");
    });
  };

  const 글작성취소 = () => {
    let confirm = window.confirm("글 작성을 취소하시겠습니까?");
    if (confirm) {
      history.push("/");
    }
  };

  const transferImg = () => {
    const formData = new FormData();
                      formData.append("file", files[0]);

                      // config에 Content-Type 설정
                      const config = {
                        headers: {
                          "Content-Type": "multipart/form-data",
                        },
                      };
                      axios
                        .post("http://localhost:8080/boardImage", formData, config)
                        .then(() => console.log("데이터 보내기 성공"))
                        .catch((err) => console.log(err));
  }

  const NOW_DATE = new Date();
  const KR_TIME_DIFF = 9 * 60 * 60 * 1000;
  const UTC = NOW_DATE.getTime() + NOW_DATE.getTimezoneOffset() * 60 * 1000;
  const KR_DATE = new Date(UTC + KR_TIME_DIFF);
  var YYYY = KR_DATE.getFullYear(); // 연 (4자리)
  var MM = ("00" + (KR_DATE.getMonth() + 1)).slice(-2); // 월 (2자리)
  var DD = ("00" + KR_DATE.getDate()).slice(-2); // 일 (2자리)

  var HH24 = ("00" + KR_DATE.getHours()).slice(-2); // 시간 (24시간 기준, 2자리)
  var MI = ("00" + KR_DATE.getMinutes()).slice(-2); // 분 (2자리)

  return (
    <div>
      {/* 로 그 아 웃 */}
      <Navibar />
      {/* Contact */}
      <div id="contact" className="form-1">
        <div className="container">
          <div className="row">
            <div className="col-lg-12">
              <h2 className="h2-heading">여행 친구 찾기</h2>
              <br />
            </div>{" "}
            {/* end of col */}
          </div>{" "}
          {/* end of row */}
          <div className="row">
            <div className="col-lg-10 offset-lg-1">
              {/* Contact Form */}
              <FormGroup>
                <h6 style={{ textAlign: "left" }}>작성자</h6>
                <div className="form-group">
                  <input
                    type="text"
                    className="form-control-input"
                    style={{ borderColor: "lightgray" }}
                    value={props.유저.name}
                  />
                </div>

                <h6 style={{ textAlign: "left" }}>작성일</h6>
                <div className="form-group">
                  <input
                    type="text"
                    className="form-control-input"
                    style={{ borderColor: "lightgray" }}
                    value={`${YYYY}년 ${MM}월 ${DD}일 ${HH24}시 ${MI}분`}
                  />
                </div>
                <h6 style={{ textAlign: "left" }}>지역</h6>
                <div className="form-group">
                  <select style={{width : "150px", float:"left"}} onChange = {(e) => {
                      setLocation(e.target.value)
                    }}>
                      {
                        지역코드.map((지역) => {
                          let 지역이름 = '';
                          if(지역.name === '경기도'){
                            지역이름 = '경기'
                          } else if(지역.name === '강원도'){
                            지역이름 = '강원'
                          } else if(지역.name === '세종특별자치시'){
                            지역이름 = '세종'
                          } else if(지역 === 11){
                            지역이름 = '제주'
                          } else {
                            지역이름 = 지역.name;
                          }
                          return <option value={지역이름}>{지역이름}</option>
                        })
                      }
                  </select>
                </div>

                <h6 style={{ textAlign: "left" }}>제목</h6>
                <div className="form-group">
                  <input
                    type="text"
                    className="form-control-input"
                    style={{ borderColor: "lightgray" }}
                    onChange={(e) => {
                      제목변경(e.target.value);
                    }}
                  />
                </div>
                <h6 style={{ textAlign: "left" }}>여행 기간</h6>
                <div className="form-group" style={{ textAlign: "left" }}>
                  <SDatePicker
                    minDate={new Date()}
                    dateFormat="yyyy년 MM월 dd일"
                    locale={ko}
                    selected={startDate}
                    onChange={(date) => setStartDate(date)}
                  />
                  <SDatePicker
                    minDate={new Date()}
                    dateFormat="yyyy년 MM월 dd일"
                    locale={ko}
                    selected={endDate}
                    onChange={(date) => setEndDate(date)}
                  />
                </div>
                <h6 style={{ textAlign: "left" }}>내용</h6>
                <div className="form-group">
                  {/* <textarea
                    className="form-control-textarea"
                    rows={15}
                    style={{ borderColor: "lightgray" }}
                    defaultValue={""}
                    onChange={(e) => {
                      내용변경(e.target.value);
                    }}
                  /> */}
                  <TextEditor 내용변경 = {내용변경}/>
                </div>
                <table>
                  <tbody>
                    <tr>
                      <th>이미지</th>
                      <td>
                        <div>
                          {fileImage && (
                            <img
                              alt="sample"
                              src={fileImage}
                              style={{ margin: "auto" , width : "400px", height : "auto"}}
                            />
                          )}
                          <div
                            style={{
                              alignItems: "center",
                              justifyContent: "center",
                            }}
                          ><br/>
                            <input
                              name="imgUpload"
                              type="file"
                              accept="image/*"
                              onChange={onLoadFile}
                            />
                            <button
                              style={{
                                backgroundColor: "lightgray",
                                color: "white",
                                width: "55px",
                                height: "40px",
                                cursor: "pointer",
                                fontSize : "12px",
                                borderRadius: "8px",
                                border:"none"
                              }}
                              onClick={deleteFileImage}
                            >
                              삭제
                            </button>
                          </div>
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table><br/>
                <div className="form-group">
                  <button
                    type="button"
                    className="form-control-submit-button"
                    style={{ width: "100px" }}
                    onClick={게시글등록}
                  >
                    완료
                  </button>
                  &nbsp;&nbsp;
                  <button
                    type="button"
                    className="form-control-submit-button"
                    style={{ width: "100px" }}
                    onClick={글작성취소}
                  >
                    취소
                  </button>
                  {/* <button onClick={() => console.log(지역코드)}>검증</button> */}
                </div>
              </FormGroup>
              {/* end of contact form */}
            </div>{" "}
            {/* end of col */}
          </div>{" "}
          {/* end of row */}
        </div>{" "}
        {/* end of container */}
      </div>{" "}
      {/* end of contact */}
      <Footer/>
      {/* Back To Top Button */}
      <button onclick="topFunction()" id="myBtn">
        <img src="images/up-arrow.png" alt="alternative" />
      </button>
      {/* end of back to top button */}
    </div>
  );
};
// DatePicker Custom
const SDatePicker = styled(DatePicker)`
  margin-top: 1rem;
  width: 200px;
  display: flex;
`;

function props화함수(state) {
  return {
    유저: state.userReducer,
    로그인상태: state.loginReducer,
    게시글 : state.boardReducer
  };
}

export default connect(props화함수)(BoardWriteForm);
