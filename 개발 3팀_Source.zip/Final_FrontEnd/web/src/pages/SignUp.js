/* eslint-disable */

import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import Navibar from "./Navibar";
import { useHistory } from "react-router";
import PopupDom from "./PopupDom";
import PopupPostCode from "./PopupPostCode";
import { FormGroup } from "@material-ui/core";
import Footer from "../components/Footer";

export default function SignUp() {
  const history = useHistory();

  const [user, setUser] = useState({});
  const [name, setName] = useState("");
  const [이름검증, 이름검증변경] = useState(false);
  const [id, setid] = useState("");
  const [아이디검증, 아이디검증변경] = useState(false);
  const [아이디중복검증, 아이디중복검증변경] = useState(false);
  const [아이디가능, 아이디가능변경] = useState(false);
  const [password, setPassword] = useState("");
  const [repassword, setRepassword] = useState("");
  const [비밀번호검증, 비밀번호검증변경] = useState(false);
  const [비밀번호재확인검증, 비밀번호재확인검증변경] = useState(false);
  const [gender, setGender] = useState("");
  const [image, setImage] = useState("");
  const [phoneNum, setPhoneNum] = useState("");
  const [basicAddress, setBasicAddress] = useState("");
  const [detailAddress, setDetailAddress] = useState("");
  const [zipCode, setZipCode] = useState("");
  const [isPopupOpen, setIsPopupOpen] = useState(false);
  const [fileImage, setFileImage] = useState("assets/images/defaultpic.png");
  const [files, setFiles] = useState("");

  const onLoadFile = (e) => {
    const file = e.target.files;
    setFiles(file);
    setImage(file[0].name);
    setFileImage(URL.createObjectURL(e.target.files[0]));
  };

  var listVar = $("input[name=genderBtn]:checked").val();

  // 파일 삭제
  const deleteFileImage = () => {
    URL.revokeObjectURL(fileImage);
    setFileImage("assets/images/defaultpic.png");
  };

  const openPostCode = () => {
    setIsPopupOpen(true);
  };

  const closePostCode = () => {
    setIsPopupOpen(false);
  };

  const transferImg = () => {
    const formData = new FormData();
    formData.append("file", files[0]);

    // config에 Content-Type 설정
    const config = {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    };
    axios
      .post("http://localhost:8080/userImage", formData, config)
      .then(() => console.log("데이터 보내기 성공"))
      .catch((err) => console.log(err));
  };

  const duplicatedUser = () => {
    axios.get("http://localhost:8080/users").then((res) => {
      console.log(id);
      res.data.forEach((e) => {
        if (id == e.id) {
          아이디중복검증변경(true);
        }
        if (id != e.id) {
          아이디가능변경(true);
        }
      });
      setTimeout(() => {
        아이디중복검증변경(false);
      }, 3000);

      setTimeout(() => {
        아이디가능변경(false);
      }, 3000);
    });
  };

  useEffect(() => {
    setGender(listVar);
    const userForm = {
      name: name,
      id: id,
      password: password,
      image: image,
      gender: gender,
      phoneNum: phoneNum,
      basicAddress: basicAddress,
      detailAddress: detailAddress,
      zipCode: zipCode,
    };
    setUser(userForm);
  }, [name, gender, image, id, password, basicAddress, detailAddress]);

  const 회원가입 = () => {
    if (id == "" || id == null) {
      아이디검증변경(true);
      setTimeout(() => {
        아이디검증변경(false);
      }, 3000);
      return;
    } else {
      아이디검증변경(false);
    }
    if (password == "" || password == null) {
      비밀번호검증변경(true);
      setTimeout(() => {
        비밀번호검증변경(false);
      }, 3000);
      return;
    } else {
      비밀번호검증변경(false);
    }

    if (repassword != password) {
      비밀번호재확인검증변경(true);
      setTimeout(() => {
        비밀번호재확인검증변경(false);
      }, 3000);
      return;
    } else {
      비밀번호재확인검증변경(false);
    }

    if (name == "" || name == null) {
      이름검증변경(true);
      setTimeout(() => {
        이름검증변경(false);
      }, 3000);
      return;
    } else {
      이름검증변경(false);
    }

    transferImg();
    axios
      .post("http://localhost:8080/user", user)
      .then(() => console.log("회원가입 성공"));
    history.push("/signUpSuccess");
  };

  return (
    <div>
      {/* Navigation */}
      <Navibar />
      {/* end of navigation */}
      {/* Contact */}
      <div id="contact" className="form-1">
        <div className="container">
          <div className="row">
            <div className="col-lg-12">
              <h2 className="h2-heading">회원가입</h2>
              <br />
            </div>{" "}
            {/* end of col */}
          </div>{" "}
          {/* end of row */}
          <div className="row">
            <div className="col-lg-10 offset-lg-1">
              {/* Contact Form */}

              <FormGroup>
                {/* <FormBox
                  type="text"
                  placeholder="아이디"
                  onChange={(e) => setid(e.target.value)}
                  
                /> */}

                <div className="form-group">
                  <input
                    type="text"
                    id="id"
                    className="form-control-input"
                    onChange={(e) => setid(e.target.value)}
                    placeholder="아이디"
                    style={{ width: "180px", borderColor: "lightgray" }}
                  />
                  <button
                    type="button"
                    style={{ marginLeft: "20px" }}
                    onClick={duplicatedUser}
                    className="btn-solid-sm"
                  >
                    중복확인
                  </button>
                </div>

                {/* <button type="button"
                    className="form-control-submit-button"
                    style={{marginLeft: "400px", width: "100px"}} onClick = {duplicatedUser}>중복확인</button> */}
                {아이디검증 ? (
                  <Validation text="아이디를 입력해주세요" color="red" />
                ) : null}
                {아이디중복검증 ? (
                  <Validation text="중복된 아이디가 존재합니다" color="red" />
                ) : null}
                {아이디가능 ? (
                  <Validation text="사용 가능한 아이디입니다" color="green" />
                ) : null}
                <FormBox
                  type="password"
                  placeholder="비밀번호"
                  onChange={(e) => setPassword(e.target.value)}
                />
                {비밀번호검증 ? (
                  <Validation text="비밀번호를 입력해주세요" color="red" />
                ) : null}
                <FormBox
                  type="password"
                  placeholder="비밀번호 재확인"
                  onChange={(e) => setRepassword(e.target.value)}
                />
                {비밀번호재확인검증 ? (
                  <Validation text="비밀번호와 일치하지 않습니다" color="red" />
                ) : null}
                <FormBox
                  type="text"
                  placeholder="이름"
                  onChange={(e) => setName(e.target.value)}
                />

                {이름검증 ? (
                  <Validation text="이름을 입력해주세요" color="red" />
                ) : null}

                <FormBox
                  type="text"
                  placeholder="전화번호"
                  onChange={(e) => setPhoneNum(e.target.value)}
                />

                <div className="form-group">
                  <input
                    type="text"
                    id="postcode"
                    className="form-control-input"
                    placeholder="우편번호"
                    value={zipCode}
                    style={{
                      width: "180px",
                      borderColor: "lightgray",
                      backgroundColor: "lightgray",
                    }}
                    disabled="true"
                  />
                  <button
                    type="button"
                    style={{ marginLeft: "20px" }}
                    onClick={openPostCode}
                    className="btn-solid-sm"
                  >
                    주소찾기
                  </button>
                </div>

                <FormBox
                  id="address"
                  type="text"
                  placeholder="주소"
                  value={basicAddress}
                  disabled="true"
                />
                <FormBox
                  id="detailAddress"
                  type="text"
                  placeholder="상세주소"
                  onChange={(e) => setDetailAddress(e.target.value)}
                />
                <div id="popupDom">
                  {isPopupOpen ? (
                    <PopupDom>
                      <PopupPostCode
                        onClose={closePostCode}
                        setBasicAddress={setBasicAddress}
                        setZipCode={setZipCode}
                      />
                    </PopupDom>
                  ) : null}
                </div>

                <div className="form-group" style={{ marginBottom: "50px" }}>
                  <input
                    className="form-check-input"
                    type="radio"
                    name="genderBtn"
                    id="genderBtn1"
                    value="여성"
                  />
                  <label for="genderBtn1">여성</label>
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  <input
                    className="form-check-input"
                    type="radio"
                    name="genderBtn"
                    id="genderBtn2"
                    value="남성"
                  />
                  <label for="genderBtn2">남성</label>
                </div>
                <div className="form-group" style={{ marginLeft: "250px" }}>
                  <table>
                    <tbody>
                      <tr
                        style={{
                          textAlign: "left",
                          fontSize: "20px",
                          fontWeight: "bold",
                        }}
                      >
                        프로필 이미지
                        <hr />
                      </tr>
                      <tr>
                        최소 100px x 100px 사이즈의 이미지 파일을 등록해주세요
                      </tr>
                      <br />
                      <tr>
                        <td>
                          <div>
                            {fileImage && (
                              <img
                                alt="sample"
                                src={fileImage}
                                style={{
                                  margin: "auto",
                                  width: "200px",
                                  height: "250px",
                                }}
                              />
                            )}
                            <div
                              style={{
                                alignItems: "center",
                                justifyContent: "center",
                              }}
                            >
                              <br />
                              <input
                                name="imgUpload"
                                type="file"
                                accept="image/*"
                                onChange={onLoadFile}
                              />
                              <button
                                style={{
                                  backgroundColor: "lightgray",
                                  color: "white",
                                  width: "55px",
                                  height: "40px",
                                  cursor: "pointer",
                                  fontSize: "12px",
                                  borderRadius: "8px",
                                  border: "none",
                                }}
                                onClick={deleteFileImage}
                              >
                                삭제
                              </button>
                            </div>
                          </div>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <div className="form-group">
                  <button
                    type="button"
                    className="form-control-submit-button"
                    style={{ width: "100px" }}
                    onClick={회원가입}
                  >
                    가입 완료
                  </button>
                </div>
              </FormGroup>
              {/* end of contact form */}
            </div>{" "}
            {/* end of col */}
          </div>{" "}
          {/* end of row */}
        </div>{" "}
        {/* end of container */}
      </div>{" "}
      {/* end of form-1 */}
      {/* end of contact */}
      <Footer />
      {/* Back To Top Button */}
      <button onclick="topFunction()" id="myBtn">
        <img src="images/up-arrow.png" alt="alternative" />
      </button>
      {/* end of back to top button */}
    </div>
  );
}

const Validation = (props) => {
  return (
    <div style={{ color: props.color, display: "inline" }}>{props.text}</div>
  );
};

const FormBox = (props) => {
  return (
    <div className="form-group">
      <input
        id={props.id}
        type={props.type}
        className="form-control-input"
        placeholder={props.placeholder}
        onChange={props.onChange}
        style={{ width: "300px", borderColor: "lightgray" }}
        value={props.value}
        disabled={props.disabled}
      />
    </div>
  );
};
