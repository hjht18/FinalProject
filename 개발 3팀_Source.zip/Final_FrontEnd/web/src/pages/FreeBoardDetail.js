import { useEffect , useState } from "react";
import { connect } from "react-redux"
import { useParams } from "react-router";
import { useHistory } from "react-router";
import Navibar from "./Navibar";
import Join from "../Join";
import '../custom.css'
import axios from "axios";
import { Link } from "react-router-dom";

const FreeBoardDetail = (props) => {

    let { code } = useParams();
    let 찾은게시글 = props.자유게시글목록.find(게시글 => {
      return 게시글.code == code;
    });

    let history = useHistory();

    const [채팅방스위치, 채팅방스위치변경] = useState(false);

    const 글삭제 = () => {
      let confirm = window.confirm('글을 삭제하시겠습니까?');
      if(confirm){
        axios.delete(`http://localhost:8080/free/${찾은게시글.code}`)
        .then(() => {
          history.goBack();
        });
      }
      
      
    }


// timestamp 날짜변환
  function unixToDateFormatter(date) {
    // yyyy-mm-dd hh:mm:ss.s
    var dateFormatt = new Date ( date );
    var year = dateFormatt.getFullYear();
    var month = 0;
    if ( dateFormatt.getUTCMonth() < 9 ){
      month = '0'+ ( dateFormatt.getUTCMonth() + 1 ).toString();
    } else {
      month = dateFormatt.getUTCMonth()+ 1;
    }
    var day = (dateFormatt.getUTCDate() < 10 ? '0' : '') + dateFormatt.getUTCDate();
   
    var hour = 0;
    if ( dateFormatt.getHours() < 10 ){
      hour = '0' + (dateFormatt.getHours()).toString();
    } else {
      hour = dateFormatt.getHours();
    }
   
    var minute = 0;
    if ( dateFormatt.getMinutes() < 10 ){
      minute = '0' + ( dateFormatt.getMinutes()).toString();
    } else {
      minute = dateFormatt.getMinutes();
    }

    var fullDateFormatt;
    fullDateFormatt = year +'-'+month+'-'+day+' '+hour+':'+minute;
    console.log ("DateFormatt : " + fullDateFormatt);
    return fullDateFormatt;
  }

  const 게시글이미지 = `/assets/boardimage/${찾은게시글.image}`;
    return(
        <div>
          <Navibar/>

          {/*  */}
  <div className="container pt-5">
    <table id="boardCss" className="table mt-5">
      <thead className="table-bordered">
        <tr>
          <th scope="row" style={{width : "250px"}}>제목</th>
          <td colSpan={5}>
            {찾은게시글.title}
          </td>
        </tr>
        <tr>
          <th scope="row">작성자</th>
          <td>
          <img src={`/assets/userimage/${찾은게시글.user.image}`} style={{width : "30px", height : "30px", borderRadius : "15px", border : "1.5px solid black"}}/>&nbsp;&nbsp;{찾은게시글.user.name}
          </td>
        </tr>
        <tr>
          <th scope="row">작성일</th>
          <td colSpan={5} id="boardFile">
            {unixToDateFormatter(찾은게시글.date)}
          </td>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th scope="row" colSpan={6} id="boardTextarea">
            {/* 글내용 */}
            <br />&nbsp;&nbsp;&nbsp;
            {
              찾은게시글.image != null
              ? <img src={게시글이미지} style={{width : "300px", height : "auto"}}/>
              : null
            }
            <br /><br /><br />&nbsp;&nbsp;&nbsp;
              <div dangerouslySetInnerHTML={{__html : 찾은게시글.content}}></div>
          </th>
        </tr>
      </tbody>
    </table>
    <div className="d-md-flex justify-content-md-end" style={{textAlign: 'right'}}>
      {
        찾은게시글.user.code === props.유저.code
        ? <div>
          <Link to={`/freeBoardModify/${찾은게시글.code}`}><button className="btn-solid-sm" style={{height:"30px", margin:"1px", position:"relative", bottom:"5px"}} >수정</button></Link>
          <button onClick={글삭제} className="btn btn-Light mb-3 right viewBtn" style={{textDecoration: 'none', margin: '1px'}}>삭제</button>
        </div>
        : null
      }
      
      <button onClick={()=> history.goBack()} className="btn mb-3 right viewBtn" style={{textDecoration: 'none', margin: '1px'}}>목록</button>
      {
        props.유저.code !== 찾은게시글.user.code
        ? <button onClick={() => {
          채팅방스위치변경(!채팅방스위치);
        }} className="btn mb-3 right viewBtn" style={{textDecoration: 'none', margin: '1px'}}>채팅하기</button>
        : null
      }
      
            {
              채팅방스위치
              ? <ChatModal activeBoard={찾은게시글} 채팅방스위치변경={채팅방스위치변경}/>
              : null
            }
    </div>
  </div>
          {/*  */}
        </div>
    );
}

const ChatModal = (props) => {
  return (
    <div className = "chatModal">
      <Join activeBoard={props.activeBoard} 채팅방스위치변경={props.채팅방스위치변경}/>
    </div>
  );
}

function props화함수(state) {
    return {
      유저: state.userReducer,
      자유게시글목록 : state.freeBoardListReducer
    };
  }

export default connect(props화함수)(FreeBoardDetail);