/* eslint-disable */

import React from 'react'
import {Link} from 'react-router-dom'
import {useState, useEffect} from 'react'
import axios from 'axios'
import Navibar from './Navibar'
import { connect } from 'react-redux'
import ModalBtn from '../components/ModalBtn'
import ModalWindow from '../components/ModalWindow'
import AwesomeSlider from 'react-awesome-slider'
import 'react-awesome-slider/dist/styles.css'
import Footer from '../components/Footer'
import Corona from './Corona'

const Home = (props) => {

  const [사진갤러리, 사진갤러리변경] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(1);
  

  useEffect( async() => {
    const SERVICE_KEY = "nioVFR5OKV5mnLAlMVcpNHQ9eJs%2FxbeC%2Bp%2B7yqjjpLiu1bzfy3TkCbuwQ%2FzJrtol4EDz3Ark3FkdEBxstzrXBA%3D%3D";
     await axios.get("http://api.visitkorea.or.kr/openapi/service/rest/PhotoGalleryService/galleryList?ServiceKey="+SERVICE_KEY+"&numOfRows=10&pageNo="+Math.floor(Math.random() * 40)+"&MobileOS=AND&MobileApp=appName&_type=json")
    .then((res) => {
        사진갤러리변경(res.data.response.body.items.item);
  });
}, []);

// 슬라이더 타이머
  useEffect(() => {
    setTimeout(() => {
      if(currentIndex >= 10) {
        setCurrentIndex(1);
      }
      setCurrentIndex(currentIndex + 1);
    }, 6000)
  }, [currentIndex]);

  // ######################################### //

  // ######################################### //

    return (
        <div>
            <Navibar/>
        {/* Header */}
        <header id="header" className="header" style={{height:"900px"}}>
          <div className="container">
            <div className="row">
              <div className="col-lg-6 col-xl-5">
                <div className="text-container">
                  <div className="section-title">WeTravel</div>
                  <h1 className="h1-large">우리 같이 여행갈래?</h1>
                  <p class="p-large">
                            여행을 가고 싶지만 혼자라서 망설여지나요?<br/>
                            그렇다면 위트래블에 고객님의 여행을 알려주세요.<br/>
                            여행을 더욱 멋지게 만들어줄 친구를 만나게 될 거예요!
                  </p>

                  <Link to="/boardWrite" className="btn-solid-lg" >바로 가기</Link>
                </div> {/* end of text-container */}
              </div> {/* end of col */}
              <div className="col-lg-6 col-xl-7">
                <div className="image-container">
                  <img className="img-fluid" src="assets/images/travelmainimage.png" alt="WeTravel" style={{maxWidth: "93%"}}/>
                </div> {/* end of image-container */}
              </div> {/* end of col */}
            </div> {/* end of row */}
          </div> {/* end of container */}
        </header> {/* end of header */}
        {/* end of header */}


        {/* Details 1 */}
        <div id="details" className="basic-1">
          <div className="container">
            <div className="row">
              <div className="col-lg-6 col-xl-7">
                <div className="image-container">
                  {/* <img className="img-fluid" src="assets/images/details-1.svg" alt="WeTravel" /> */}
                  <div style={{marginTop : "50px"}}>
                  <AwesomeSlider selected={currentIndex} organicArrows={false}>
                    {
                      사진갤러리 && 사진갤러리.map((사진) => {
                      return (
                        <div data-src={
                          사진.galWebImageUrl
                        }/>
                      )
                      }) 
                    }
                  </AwesomeSlider>
                  </div>
                </div> {/* end of image-container */}
              </div> {/* end of col */}
              <div className="col-lg-6 col-xl-5">
                <div className="text-container" >
                  <h1 className="h1-large"  style={{position:"relative", bottom:"20px"}}>
                    여행지가 고민이세요?</h1><br/>
                    <p>한국관광공사가 제공하는 국내의 아름다운 여행지를 보며 여행 친구와 여행지를 정해보세요!</p>
                    <hr/>
                  <AwesomeSlider selected={currentIndex} 
                  //  height : "200px", width : "280px", 
                  style={{color : "white",
                  display: "flex", marginTop : "20px", position : "relative", bottom:"20px", right:"30px"}} 
                  bullets={false} 
                  organicArrows={false}>
                    {
                      사진갤러리 && 사진갤러리.map((사진) => {
                        return (
                          <div style = {{backgroundColor : "white", marginLeft:"-100px", textAlign : "left", width : "500px"}}> 
                            <h5>{사진.galTitle}</h5>
                            <p style = {{fontSize : "16px"}}>촬영장소 : {사진.galPhotographyLocation}<br/>
                            촬영일 : {사진.galPhotographyMonth}<br/>
                            촬영자 : {사진.galPhotographer}</p>
                          </div>
                        );
                      })
                    }
                  </AwesomeSlider>
                </div> {/* end of text-container */}
              </div> {/* end of col */}
            </div> {/* end of row */}
          </div> {/* end of container */}
        </div> {/* end of basic-1 */}
        {/* end of details 1 */}
        {/* Details Modal */}
        <ModalWindow image="https://t3.daumcdn.net/thumb/R720x0.fjpg/?fname=http://t1.daumcdn.net/brunch/service/user/cnoC/image/MVXKXCbEwk6GIO7bzjVpafxjSaA.jpg"/>
        {/* end of details modal */}

           {/* 쿠폰 사러가기 */}
           <div id="details" className="basic-1" style={{height:"600px"}}>
          <div className="container">
            <div className="row">
              <div className="col-lg-6 col-xl-5">
                <div className="text-container">
                  {/* <div className="section-title">WeTravel</div> */}
                  <h1 className="h1-large">여행을 더 저렴하게!</h1><br/>
                  <p class="p-large">
                            갈 곳은 많고 사야하는 입장권이 많으시다고요?<br/>
                            그렇다면 위트래블의 할인 쿠폰을 이용하여<br/> 
                            저렴하게 여행을 즐겨보세요!<br/>
                  </p>


                  <Link to="/pass" className="btn-solid-lg" >쿠폰 사러 가기</Link>
                </div> {/* end of text-container */}
              </div> {/* end of col */}
              <div className="col-lg-6 col-xl-7">
                <div className="image-container">
                  <img className="img-fluid" src="assets/images/Discount-pana.png" alt="WeTravel" style={{position:"relative", bottom:"100px"}}/>
                </div> {/* end of image-container */}
              </div> {/* end of col */}
            </div> {/* end of row */}
          </div> {/* end of container */}
        </div> {/* end of header */}
        {/* 쿠폰 사러가기 끝 */}
        <div id="details" className="basic-1" style={{height:"600px"}}> 
          <div className="container" >
            <div className="row" >
              <Corona/>
         
            </div>
          </div>
        </div>
        <Footer/>
        
        {/* end of back to top button */}
        </div>
    )
}

function props화함수 (state) {
  return {
    유저 : state.userReducer,
    로그인상태 : state.loginReducer
  }
}
export default connect(props화함수)(Home);