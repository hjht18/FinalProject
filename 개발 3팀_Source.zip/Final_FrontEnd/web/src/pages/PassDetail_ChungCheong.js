import React from 'react';
import Navibar from './Navibar';
import { useState, useEffect } from 'react';
import requestPay from './requestPay';
import Footer from '../components/Footer';
import { connect } from 'react-redux';

const PassDetail_ChungCheong = (props) => {

    const [이름, 이름변경] = useState('충청 투어패스');
    const [가격, 가격변경] = useState(7900);
    const [수량, 수량변경] = useState(1);
    const [총액, 총액변경] = useState(0);

    useEffect(() => {
        총액변경(가격 * 수량);
    }, [가격, 수량]);
          
    return (
        <div>
  {/* Navigation */}
  <Navibar/>
  {/* end of navigation */}
  <header className="py-5">
    <div className="container px-4 px-lg-5 my-5">
      <div className="text-center text-white">
        <h1 className="display-4 fw-bolder">위트래블 투어패스</h1><br />
        <p className="lead fw-normal mb-0">위트래블 투어패스로 설정된 시간동안 자유롭게 관광시설을 이용해보세요!</p>
      </div>
    </div>
  </header>
  {/* Product section*/}
  <section className="py-5">
    <div className="container px-4 px-lg-5 my-5">
      <div className="row gx-4 gx-lg-5 align-items-center">
        <div className="col-md-6">
          <img className="card-img-top mb-5 mb-md-0" src="http://img3.tmon.kr/cdn3/deals/2020/12/10/4926748190/front_sub_d6894.jpg" alt="충청패스" height="400px" />
        </div>
        <div className="col-md-6">
          <h1 className="display-6 fw-bolder">{이름}</h1><br />
          <div className="fs-3 mb-5">
            <strong>{가격.toLocaleString()}원</strong>
          </div>
          <p className="lead">48시간 프리패스 자유이용권<br />
          </p>
          <div name="form">
            수량
            <input type="text" value={수량} className="form-control-input" style={{width: '100px', height: '30px', borderColor: 'lightgray', marginBottom: '5px'}} />

            <input type="button" defaultValue=" + " onClick={() => {수량변경(수량 + 1)}} style={{backgroundColor: '#ffe7eb', borderRadius: '8px', border: 'none', color: '#ff5574'}} />&nbsp;
            <input type="button" defaultValue=" - " onClick={() => {
                if(수량 > 0)
                수량변경(수량 - 1)
                }} style={{backgroundColor: '#ffe7eb', borderRadius: '8px', border: 'none', color: '#ff5574'}} /><br />
            총 금액  {총액.toLocaleString()} 원
          </div><br />
          <div className="d-flex">
            <button type="button" className="form-control-submit-button" style={{width: '100px'}}>장바구니</button>&nbsp;&nbsp;
            <button type="button" className="form-control-submit-button" style={{width: '100px'}} onClick={() => {requestPay(이름, 총액, props.유저)}}>바로 결제</button>
          </div>
        </div>
      </div>
    </div>
  </section>
  <div className="container px-4 px-lg-5 my-5">
    <div className=" text-white">
      <p className="lead fw-normal mb-0"><strong>투어패스 유의사항</strong></p><br />
      <p className="lead" style={{fontSize: '15px'}}>
        1. 투어패스 첫 사용시간 기준으로 48시간 무제한 이용가능합니다. (동일시설 중복이용 불가)<br />
        2. 1인 1티켓 이용은 필수입니다.<br />
        3. 각 관광지 이용시, 운영시간 및 휴무일과 유의사항등 자세한 내용은 방문 전 업장 홈페이지 및 유선 확인 바랍니다.<br />
        4. 코로나 19로 인해 자유이용시설의 운영시간 및 휴관일이 바뀐곳이 있으니 방문전 관광지에 운영여부를 반드시 확인하시기 바랍니다.<br />
      </p><br />
      <p className="lead fw-normal mb-0"><strong>투어패스 환불 규정 안내</strong></p><br />
      <p className="lead" style={{fontSize: '15px'}}>
        1. 한 곳 이상의 관광지에서 티켓을 사용하신 경우 부분환불 불가능합니다.<br />
        2. 특별할인가맹점 이용 시 환불 불가능합니다.<br />
        3. 미사용 티켓의 한하여 유효기간 내 100% 환불 가능합니다.<br />
      </p><br />
    </div>
  </div>
  <Footer/>
  {/* Back To Top Button */}
  <button onClick="topFunction()" id="myBtn">
    <img src="assets/images/up-arrow.png" alt="alternative" />
  </button>
  {/* end of back to top button */}
</div>

    )
}

function props화함수(state) {
  return {
    유저: state.userReducer
  };
}

export default connect(props화함수)(PassDetail_ChungCheong);