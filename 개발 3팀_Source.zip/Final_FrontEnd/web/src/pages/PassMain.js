import React from 'react';
import Navibar from './Navibar'
import {Link} from 'react-router-dom'
import Footer from '../components/Footer';

const PassMain = () => {
    return(
        <div>
  {/* Navigation */}
  <Navibar/>
  {/* end of navigation */}
  <header className="py-5">
    <div className="container px-4 px-lg-5 my-5">
      <div className="text-center text-white">
        <h1 className="display-4 fw-bolder">위트래블 투어패스</h1><br />
        <p className="lead fw-normal mb-0">위트래블 투어패스로 설정된 시간동안 자유롭게 관광시설을 이용해보세요!</p>
      </div>
    </div>
  </header>
  {/* Section*/}
  <section className="py-5">
    <div className="container px-4 px-lg-5 mt-5">
      <div className="row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-center">
        <div className="col mb-5">
          <div className="card h-100">
            <Link to="/pass/jeju" style={{textDecoration: 'none'}}>
              {/* Product image*/}
              <img className="card-img-top" src="https://encrypted-tbn3.gstatic.com/licensed-image?q=tbn:ANd9GcQQdPxZMNsGBt4rqGlMo_xkc5KC636Zf3Emq33-oKopM1uy1ACgAXrk_DPGQmcaaskm3hOoq3tx9_h-60RMf_Bidg" alt="제주 투어패스" height="223px" />
              {/* Product details*/}
              <div className="card-body p-4">
                <div className="text-center">
                  {/* Product name*/}
                  <h5 className="fw-bolder">제주 투어패스</h5>
                  {/* Product price*/}
                  9,900원
                </div>
              </div>
              {/* Product actions*/}
            </Link><div className="card-footer p-4 pt-0 border-top-0 bg-transparent"><Link to="/pass/jeju" style={{textDecoration: 'none'}}>
              </Link><div className="text-center"><Link to="/pass/jeju" style={{textDecoration: 'none'}} /><Link className="btn  mt-auto" style={{backgroundColor: '#ff5474', color: '#ffff'}} to="/pass/jeju">자세히 보기</Link></div>
            </div>
          </div>
        </div>
        <div className="col mb-5">
          <div className="card h-100">
            <Link to="/pass/yeongnam" style={{textDecoration: 'none'}}>
              {/* Sale badge*/}
              <div className="badge text-white position-absolute" style={{top: '0.5rem', right: '0.5rem', backgroundColor: '#ff5474'}}>할인</div>
              {/* Product image*/}
              <img className="card-img-top" src="http://gdimg.gmarket.co.kr/1826522327/still/400?ver=1610001175" alt="영남패스" height="223px"/>
              {/* Product details*/}
              <div className="card-body p-4">
                <div className="text-center">
                  {/* Product name*/}
                  <h5 className="fw-bolder">영남 투어패스</h5>
                  {/* Product price*/}
                  <span className="text-muted text-decoration-line-through">9,900원</span>
                  7,900원
                </div>
              </div>
              {/* Product actions*/}
            </Link><div className="card-footer p-4 pt-0 border-top-0 bg-transparent"><Link to="/pass/yeongnam" style={{textDecoration: 'none'}}>
              </Link><div className="text-center"><Link to="/pass/yeongnam" style={{textDecoration: 'none'}} /><Link className="btn mt-auto" style={{backgroundColor: '#ff5474', color: '#ffff'}} to="/pass/yeongnam">자세히 보기</Link></div>
            </div>
          </div>
        </div>
        <div className="col mb-5">
          <div className="card h-100">
            <Link to="/pass/honam" style={{textDecoration: 'none'}}>
              {/* Product image*/}
              <img className="card-img-top" src="https://img.hankyung.com/photo/201211/2012112570371_2012112539581.jpg" alt="호남패스" height="223px" />
              {/* Product details*/}
              <div className="card-body p-4">
                <div className="text-center">
                  {/* Product name*/}
                  <h5 className="fw-bolder">호남 투어패스</h5>
                  {/* Product price*/}
                  9,900원
                </div>
              </div>
              {/* Product actions*/}
            </Link><div className="card-footer p-4 pt-0 border-top-0 bg-transparent"><Link to="/pass/honam" style={{textDecoration: 'none'}}>
              </Link><div className="text-center"><Link to="/pass/honam" style={{textDecoration: 'none'}} /><Link className="btn  mt-auto" style={{backgroundColor: '#ff5474', color: '#ffff'}} to="/pass/honam">자세히 보기</Link></div>
            </div>
          </div>
        </div>
        <div className="col mb-5">
          <div className="card h-100">
            <Link to="/pass/gangwon" style={{textDecoration: 'none'}}>
              {/* Sale badge*/}
              <div className="badge text-white position-absolute" style={{top: '0.5rem', right: '0.5rem', backgroundColor: '#ff5474'}}>할인</div>
              {/* Product image*/}
              <img className="card-img-top" src="https://cdn.pixabay.com/photo/2015/09/26/05/06/mt-seoraksan-958642_640.jpg" alt="강원패스" height="223px" />
              {/* Product details*/}
              <div className="card-body p-4">
                <div className="text-center">
                  {/* Product name*/}
                  <h5 className="fw-bolder">강원 투어패스</h5>
                  {/* Product price*/}
                  <span className="text-muted text-decoration-line-through">9,900원</span>
                  7,900원
                </div>
              </div>
              {/* Product actions*/}
            </Link><div className="card-footer p-4 pt-0 border-top-0 bg-transparent"><Link to="/pass/gangwon" style={{textDecoration: 'none'}}>
              </Link><div className="text-center"><Link to="/pass/gangwon" style={{textDecoration: 'none'}} /><Link className="btn  mt-auto" style={{backgroundColor: '#ff5474', color: '#ffff'}} to="/pass/gangwon">자세히 보기</Link></div>
            </div>
          </div>
        </div>
        <div className="col mb-5">
          <div className="card h-100">
            <Link to="/pass/chungcheong" style={{textDecoration: 'none'}}>
              {/* Product image*/}
              <img className="card-img-top" src="http://img3.tmon.kr/cdn3/deals/2020/12/10/4926748190/front_sub_d6894.jpg" alt="충청패스" height="223px" />
              {/* Product details*/}
              <div className="card-body p-4">
                <div className="text-center">
                  {/* Product name*/}
                  <h5 className="fw-bolder">충청 투어패스</h5>
                  {/* Product price*/}
                  7,900원
                </div>
              </div>
              {/* Product actions*/}
            </Link>
            
            <div className="card-footer p-4 pt-0 border-top-0 bg-transparent">
                <Link to="/pass/chungcheong" style={{textDecoration: 'none'}}></Link>
                <div className="text-center"><a to="/pass/chungcheong" style={{textDecoration: 'none'}} />
                <Link className="btn  mt-auto" style={{backgroundColor: '#ff5474', color: '#ffff'}} to="/pass/chungcheong">자세히 보기</Link></div>
            </div>
          </div>
        </div>
        <div className="col mb-5">
          <div className="card h-100">
            <Link to="/pass/seoul" style={{textDecoration: 'none'}}>
              {/* Sale badge*/}
              <div className="badge text-white position-absolute" style={{top: '0.5rem', right: '0.5rem', backgroundColor: '#ff5474'}}>할인</div>
              {/* Product image*/}
              <img className="card-img-top" src="http://img1.tmon.kr/cdn3/deals/2019/10/10/2532178562/front_sub_e9cce.jpg" alt="서울패스" height="223px" />
              {/* Product details*/}
              <div className="card-body p-4">
                <div className="text-center">
                  {/* Product name*/}
                  <h5 className="fw-bolder">서울 투어패스</h5>
                  {/* Product price*/}
                  <span className="text-muted text-decoration-line-through">11,900원</span>
                  8,900원
                </div>
              </div>
              {/* Product actions*/}
            </Link>
            <div className="card-footer p-4 pt-0 border-top-0 bg-transparent"><Link to="/pass/seoul" style={{textDecoration: 'none'}}>
              </Link><div className="text-center"><Link to="/pass/seoul" style={{textDecoration: 'none'}} /><Link className="btn  mt-auto" style={{backgroundColor: '#ff5474', color: '#ffff'}} to="/pass/seoul">자세히 보기</Link></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <Footer/>
  {/* Back To Top Button */}
  <button onclick="topFunction()" id="myBtn">
    <img src="assets/images/up-arrow.png" alt="alternative" />
  </button>
  {/* end of back to top button */}
</div>

    );
}

export default PassMain;