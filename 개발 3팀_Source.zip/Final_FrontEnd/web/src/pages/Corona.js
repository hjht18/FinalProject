import {useRef, useState, useEffect} from 'react';
// import { Chart, registerables } from 'chart.js';
import Chart from 'chart.js/auto'
import React from 'react';
import axios from 'axios';
import moment from 'moment';
import { Bar, Line } from 'react-chartjs-2';


const Corona = React.memo(() => {
    // 코로나 관련
    const [loaded, setLoaded] = useState(false);
    const [데이터, 데이터변경] = useState(0);
    // const [test, setTest] = useState(0);
    
    const today = moment(new Date()).format("YYYYMMDD");
    const weekAgo = moment(new Date()).add(-1,'week').format("YYYYMMDD");
    console.log(today)
    console.log(weekAgo);
    const chart1Day = moment(new Date()).add(-1,'day').format("MM.DD");
    const chart2Day = moment(new Date()).add(-2,'day').format("MM.DD");
    const chart3Day = moment(new Date()).add(-3,'day').format("MM.DD");
    const chart4Day = moment(new Date()).add(-4,'day').format("MM.DD");
    const chart5Day = moment(new Date()).add(-5,'day').format("MM.DD");
    const chart6Day = moment(new Date()).add(-6,'day').format("MM.DD");
 
    useEffect(() => {
    // 코로나 발생이후 총 감염 현황 합계 
    // "http://openapi.data.go.kr/openapi/service/rest/Covid19/getCovid19InfStateJson?serviceKey=FWwVh1nbtv0NAi%2BekPsLptmVbGpJte540iNETL2yhx5K3IlqrX23EBOwoOLdQSkF119VCvQaSXHmnPKtZXL5%2BA%3D%3D&pageNo=1&numOfRows=10&startCreateDt="+weekAgo+"&endCreateDt="+today+"&_type=json"
    //  코로나 지역별 및 합계  현황
    axios.get("http://openapi.data.go.kr/openapi/service/rest/Covid19/getCovid19SidoInfStateJson?serviceKey=FWwVh1nbtv0NAi%2BekPsLptmVbGpJte540iNETL2yhx5K3IlqrX23EBOwoOLdQSkF119VCvQaSXHmnPKtZXL5%2BA%3D%3D&pageNo=1&numOfRows=10&startCreateDt="+weekAgo+"&endCreateDt="+today+"&_type=json")
        .then((a)=>{
          if(loaded === false){
            데이터변경(a.data.response.body.items.item);
            // setTest(a.data.response.body.items.item[18]);
        };
        setLoaded(true);
        }).catch((error) =>{
          console.log(error);
        });
  }, []);
    const data = {
      labels: [ // 각 수치 x값 이름 label
        chart6Day,
        chart5Day, 
        chart4Day, 
        chart3Day, 
        chart2Day, 
        chart1Day
      ],
        datasets: [
          {
            data: [ // 차트에 들어갈 값 , DATA
                    데이터[113]?.incDec, 
                    데이터[94]?.incDec, 
                    데이터[75]?.incDec, 
                    데이터[56]?.incDec, 
                    데이터[37]?.incDec, 
                    데이터[18]?.incDec,
                  ],
                  backgroundColor: 'rgb(255, 85, 116)',
                  borderColor: 'rgb(255, 85, 116)',
            tension: 0.1,
          },
        ],
    };
    if (loaded === false){
      return loaded;
    } else {
      return (
        <>

  <div className="col-lg-6 col-xl-7">
                <div className="image-container">

          <div style={{textAlign:'center',}}>
              {chart1Day} 신규확진 :
              <b style={{color:'#ff5574',}}> {데이터[18]?.incDec} </b>
              명
          </div><br />

        {/* <h2>위트래블에서 코로나 현황을 알려드려요 </h2><br/> */}
          <div className="chart" > 
            <Bar 
              redraw
              data={data}
              width={350}
              height={350}
              options={
                {
                  plugins:{
                    legend: {
                  display: false,
                }},
                  scales: {
                    y: { // 차트 수치  Y값 시작점 0
                      beginAtZero: true
                    }
                  },
                responsive: true,
                maintainAspectRatio: false,
              }}
            />
          </div>
                </div> {/* end of image-container */}
              </div> {/* end of col */}

              <div className="col-lg-6 col-xl-5">
  <div className="text-container" style={{position:"relative", bottom:"60px"}}>
                  <div className="section-title">COVID-19</div>
                  <h1 className="h1-large">바로 보는 코로나 현황</h1><br/>
                  <p class="p-large">
                  고객님의 안전한 여행을 위해<br/> 위트래블에서 준비한 지역별 코로나 발생 동향을<br/> 바로 확인해보세요.<br/>
                  </p><br/><br/>

                  <a target="_blank" href="http://ncov.mohw.go.kr/bdBoardList_Real.do?brdId=1&brdGubun=13&ncvContSeq=&contSeq=&board_id=&gubun=" className="btn-solid-lg" >코로나 현황 보러 가기</a>
                </div> {/* end of text-container */}
  </div>
        </>
      )
    }
});
export default Corona;