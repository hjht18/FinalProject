import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import Footer from '../components/Footer'
import Navibar from './Navibar'

export default function SingUpSuccess(){
  return(
    <div>
        <Navibar/>
        {/* Contact */}
        <div id="contact" className="form-1">
          <div className="container">
            <div className="row">
              <div className="col-lg-12">
                <h2 className="h2-heading">위트래블 가입을 축하드립니다!</h2>
                <p className="p-heading">
                  회원가입이 성공적으로 완료되었습니다.<br />
                  위트래블에서 여행을 더욱 특별하게 해줄 동행을 구해보세요!
                </p>
                <br />
                <br />
                <div className="form-group">
                  <Link to="/login"><button type="submit" className="form-control-submit-button" style={{width: '200px'}}>로그인 하러 가기</button></Link>
                </div>
              </div> {/* end of col */}
            </div> {/* end of row */}
          </div> {/* end of container */}
        </div> {/* end of form-1 */}
        {/* end of contact */}
        <Footer/>
        {/* Back To Top Button */}
        <button onclick="topFunction()" id="myBtn">
          <img src="assets/images/up-arrow.png" alt="alternative" />
        </button>
        {/* end of back to top button */}
    </div>
  ) 
}