import React, { useEffect } from "react";
import { useHistory } from "react-router";
import { connect } from 'react-redux';
const Profile = (props) => {
  const history = useHistory();
  const getProfile = async () => {
    try {
      // Kakao SDK API를 이용해 사용자 정보 획득
      let data = await window.Kakao.API.request({
        url: "/v2/user/me",
      });
      // 사용자 정보 변수에 저장
      console.log(data.properties.nickname);
      props.dispatch({ type: "로그인" });
      props.dispatch({ type: "로그인유저", payload: {name : data.properties.nickname} });
    } catch (err) {
      console.log(err);
    }
  };
  useEffect(() => {
    getProfile();
    alert('간편로그인에 성공하였습니다');
    history.push("/");
  }, []);
  return (
    <div>
      <h2>카카오 간편로그인</h2>
    </div>
  );
};

function props화함수(state) {
  return {
    유저: state.userReducer,
    로그인상태: state.loginReducer,
  };
}

export default connect(props화함수)(Profile);