/* eslint-disable */

import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { connect } from "react-redux";
import axios from "axios";
import JoinAtNav from "../JoinAtNav";
import { useHistory } from "react-router";

const Navibar = (props) => {
  const 공지사항클릭 = () => {
    // axios
    //   .post("http://localhost:9003/board/getUser", props.유저)
    //   .then(() => console.log("유저정보 전달 성공"))
    //   .catch(() => console.log("전달 실패"));
    // window.location.href = `http://localhost:9003/board/list?num=1&name=${props.유저.name}`;
    axios.get(`http://localhost:9003/board/list?num=1&code=${props.유저.code}`).then(
      () => {
        window.location.href = `http://localhost:9003/board/list?num=1&code=${props.유저.code}`;
      }
    );
  };

  // useEffect(() => {
  //   axios.post("http://localhost:9003/board/transferUser")
  //   .then((res) => {
  //     if(res.data != {}){
  //       props.dispatch({type : "로그인유저", payload : res.data})
  //       props.dispatch({type : "로그인"})
  //     }
  //   });
  // }, []);

  const [message, setMessage] = useState("");
  const [messageSwitch, setMessageSwitch] = useState(false);
  const [latestMsg, setLatestMsg] = useState("");
  const [채팅방스위치, 채팅방스위치변경] = useState(false);

  const history = useHistory();

  return (
    <>
      {/* Navigation */}
      <nav
        id="navbarExample"
        className="navbar navbar-expand-lg fixed-top navbar-light"
        aria-label="Main navigation"
      >
        <div className="container">
          {/* Image Logo */}
          <Link to="/" className="navbar-brand logo-image">
            <div width="222px" height="50px">
              <img
                src="/assets/images/LOGO_origin_516.png"
                alt="WeTravelLogo"
                style={{ width: "60px", height: "45px" }}
              />
              <img
                src="/assets/images/wetravel_blk.png"
                style={{ position: "relative", right: "13px" }}
              />
            </div>
          </Link>
          {/* Text Logo - Use this if you don't have a graphic logo */}
          {/* <a class="navbar-brand logo-text" href="index.html">Zinc</a> */}
          <button
            className="navbar-toggler p-0 border-0"
            type="button"
            id="navbarSideCollapse"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon" />
          </button>
          <div
            className="navbar-collapse offcanvas-collapse"
            id="navbarsExampleDefault"
          >
            <ul className="navbar-nav ms-auto navbar-nav-scroll">
              {/* <li className="nav-item">
                <a
                  className="nav-link active"
                  aria-current="page"
                  href="#header"
                >
                  소개
                </a>
              </li> */}
              <li className="nav-item">
                <a className="nav-link" onClick={공지사항클릭}>
                  공지사항
                </a>
              </li>
              <li className="nav-item dropdown">
                <a
                  className="nav-link dropdown-toggle"
                  href="#"
                  id="dropdown01"
                  data-bs-toggle="dropdown"
                  aria-expanded="false"
                >
                  동행관련
                </a>
                <ul className="dropdown-menu" aria-labelledby="dropdown01">
                  <li>
                    <Link to="/boardList" className="dropdown-item">
                      동행찾기
                    </Link>
                  </li>
                  <li>
                    <div className="dropdown-divider" />
                  </li>
                  <li>
                    <Link to="/pass" className="dropdown-item">
                      쿠폰
                    </Link>
                  </li>
                  <li>
                    <div className="dropdown-divider" />
                  </li>
                  <li>
                    <button
                      type="button"
                      className="dropdown-item"
                      onClick={() => {
                        if (!props.로그인상태) {
                          alert("로그인 상태여야 합니다");
                          history.push("/login");
                        } else {
                          채팅방스위치변경(!채팅방스위치);
                        }
                      }}
                    >
                      채팅방
                    </button>
                  </li>
                </ul>
              </li>
              <li className="nav-item">
                <Link to="/freeBoardList" className="nav-link">
                  커뮤니티
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/">
                  <a className="nav-link">Home</a>
                </Link>
              </li>
            </ul>
            {props.로그인상태 ? `${props.유저.name}님 안녕하세요` : null}
            <span className="nav-item">
              {!props.로그인상태 ? (
                <Link to="/login">
                  <button className="btn-solid-sm">로그인</button>
                </Link>
              ) : (
                <button
                  className="btn-solid-sm"
                  onClick={() => {
                    if(confirm('로그아웃 하시겠습니까?')){
                      props.dispatch({ type: "로그아웃" });
                      history.push("/");
                    } else {
                      null
                    }
                  }}
                >
                  로그아웃
                </button>
              )}
              {!props.로그인상태 ? null : (
                <Link to="/modify">
                  <button className="btn-solid-sm">정보수정</button>
                </Link>
              )}
              {/*  */}
              <div
                style={{ cursor: "pointer" }}
                onClick={() => {
                  setMessageSwitch(!messageSwitch);
                }}
              >
                {/* {message}
                  {
                    messageSwitch
                    ? <>
                      <div>보낸사람 : {latestMsg.from}</div>
                      <div>시간 : {latestMsg.time}</div>
                      <div>메세지 내용 : {latestMsg.message}</div>
                    </>
                    : null
                  } */}

                {채팅방스위치 ? (
                  <ChatModal 채팅방스위치변경={채팅방스위치변경} />
                ) : null}
              </div>
              {/*  */}
            </span>
          </div>{" "}
          {/* end of navbar-collapse */}
        </div>{" "}
        {/* end of container */}
      </nav>{" "}
      {/* end of navbar */}
      {/* end of navigation */}
    </>
  );
};

function props화함수(state) {
  return {
    유저: state.userReducer,
    로그인상태: state.loginReducer,
    메세지: state.messageReducer,
    알람: state.alermReducer,
  };
}

const ChatModal = (props) => {
  return (
    <div className="chatModal">
      <JoinAtNav 채팅방스위치변경={props.채팅방스위치변경} />
    </div>
  );
};

export default connect(props화함수)(Navibar);
