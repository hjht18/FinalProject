import "./chat.css";
import io from "socket.io-client";
import { useState, useEffect } from "react";
// import Chat from "./Chat";
import ChatTest from "./ChatTest";
import { connect } from "react-redux";


const socket = io.connect("http://localhost:3001");

function JoinTest(props) {
  const [from, setFrom] = useState("");     // DB에서 from 정보를 받아서 설정
  const [to, setTo] = useState("");
  const [room, setRoom] = useState(props.activeBoard.user.code);     // DB에서 room 정보를 받아서 설정

  useEffect(() => {
    if(props.로그인상태){
      setFrom(props.유저.name);
    }
    setTo(props.activeBoard.user.name);
    // setRoom();
  }, []);

  return (
    <div className="Join">
        <ChatTest socket={socket} to={to} from={from} room={room} props={props}/>
    </div>
  );
}

function props화함수(state) {
  return {
    유저: state.userReducer,
    로그인상태: state.loginReducer,
    게시글: state.boardReducer,
    게시글목록: state.boardListReducer,
    메세지 : state.messageReducer
  };
}

export default connect(props화함수)(JoinTest);