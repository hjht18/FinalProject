import React from 'react'
import JoinTest from './JoinTest'

export default function Join(props) {

  const 찾은게시글 = props.activeBoard;
  return (
    <div>
        <JoinTest activeBoard={찾은게시글} 채팅방스위치변경 = {props.채팅방스위치변경}/>
    </div>
  )
}






// ############################################################ //

// import "./chat.css";
// import io from "socket.io-client";
// import { useState } from "react";
// import Chat from "./Chat";

// const socket = io.connect("http://localhost:3001");

// function Join() {
//   const [username, setUsername] = useState("");     // DB에서 from 정보를 받아서 설정
//   const [room, setRoom] = useState("");             // DB에서 room 정보를 받아서 설정
//   const [showChat, setShowChat] = useState(false);  // true로 설정

//   const joinRoom = () => {
//     if (username !== "" && room !== "") {
//       socket.emit("join_room", room);
//       setShowChat(true);
//     }
//   };

//   return (
//     <div className="Join">
//       {!showChat ? (
//         <div className="joinChatContainer" style={{marginTop : "100px", backgroundColor : "white", zIndex : "100"}}>
//           <h3>위트래블 채팅</h3>
//           <input
//             type="text"
//             placeholder="닉네임"
//             onChange={(event) => {
//               setUsername(event.target.value);
//             }}
//           />
//           <input
//             type="text"
//             placeholder="방번호"
//             onChange={(event) => {
//               setRoom(event.target.value);
//             }}
//           />
//           <button onClick={joinRoom}>입장하기</button>
//         </div>
//       ) : (
//         <Chat socket={socket} username={username} room={room} />
//       )}
//     </div>
//   );
// }

// export default Join;
