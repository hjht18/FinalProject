import React, { useEffect, useState } from "react";
import ScrollToBottom from "react-scroll-to-bottom";
import './chat.css'
import { useHistory } from 'react-router';
import axios from "axios";

function Chat({ socket, from, to, room, props }) {

  
  const [currentMessage, setCurrentMessage] = useState("");
  const [messageList, setMessageList] = useState([]);     // DB에서 값을 받아서 여기에 설정
  const [alerm, setAlerm] = useState(false);
  const history = useHistory();

  const sendMessage = async () => {
    if (currentMessage !== "") {

      const messageData = {
        room: room,
        from: from,
        to : to,
        message: currentMessage,
        time:
          new Date(Date.now()).getHours() +
          ":" +
          (new Date(Date.now()).getMinutes() < 10 ? '0' : '') + new Date(Date.now()).getMinutes(),
      };

      await socket.emit("send_message", messageData);
      setMessageList((list) => [...list, messageData]);
      setCurrentMessage("");
                               // 이 정보를 DB에 저장! ({room, author, message, time})
      axios.post("http://localhost:8080/chatSave", messageData)
      .then(() => {
        console.log('메세지 저장 성공');
        console.log(messageData);
        setAlerm(!alerm);
        // from에 대한 정보를 to에 전달해야 함
        props.dispatch({ type : '메세지변경', payload : messageData});
        props.dispatch({ type : '알람변경'});
      });
    }
  };

  useEffect(() => {
    console.log(room);
    axios.get("http://localhost:8080/chatList/"+room).then(res => setMessageList(res.data));
  }, [alerm]); 

  useEffect(() => {
    socket.on("receive_message", (data) => {
      setMessageList((list) => [...list, data]);
    });
  }, [socket]);

  return (
    <div className="chat-window">
      <div className="chat-header">
      <div id="less_than" onClick={() => {
          const confirm = window.confirm('채팅방을 나가시겠습니까?');
          if(confirm){
            // history.goBack();
            props.채팅방스위치변경();
          }
        }} >&lt;</div>
      <div id="user_nick">{to}</div>   {/* 상대방 아이디 */}
      </div>
      <div className="chat-body">
        <ScrollToBottom className="message-container">
          {messageList.map((messageContent) => {
            return (
              <div
                className="message"
                id={from === messageContent.from ? "other" : "you"}
              >
                <div>
                  <div className="message-content">
                    <p>{messageContent.message}</p>
                  </div>
                  <div className="message-meta">
                    <p id="time">{messageContent.time}</p>
                    {/* <p id="author">{messageContent.author}</p> */}
                  </div>
                </div>
              </div>
            );
          })}
        </ScrollToBottom>
      </div>
      <div className="chat-footer">
        <textarea
          type="text"
          value={currentMessage}
          placeholder="메세지를 입력해주세요"
          onChange={(event) => {
            setCurrentMessage(event.target.value);
          }}
          onKeyPress={(event) => {
            if(event.key === "Enter") {
              sendMessage();
            }
          }}
        />
        <button id="send_btn" onClick={sendMessage}>보내기</button>
      </div>
    </div>
  );
}

export default Chat;