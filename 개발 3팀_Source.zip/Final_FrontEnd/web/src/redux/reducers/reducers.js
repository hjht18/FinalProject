import { combineReducers } from "redux";
import * as type from "../constants/actionTypes";

const chatStates = {
  chatList: [],
  socketId: null,
};

const chatReducer = (state = chatStates, action) => {
  switch (action.type) {
    case type.MY_SOCKET_ID:
      return { ...state, socketId: action.socketId };
    case type.RECEIVE_CHAT:
      let newChatList = state.chatList.slice();
      newChatList.push(action.data);
      return { ...state, chatList: newChatList };
    case type.CLEAR_CHAT:
      return { ...state, chatList: [] };
    default:
      return state;
  }
};

let defaultUser = {
  code: 0,
  id: "디폴트아이디",
  name: "디폴트이름",
  password: "디폴트비번",
  gender: "",
  phoneNum: "",
  zipCode: "",
  basicAddress: "",
  detailAddress: "",
  image: "",
};

const userReducer = (state = defaultUser, action) => {
  if (action.type === "로그인유저") {
    let user = action.payload;
    console.log(action.payload);
    return user;
  }
  return state;
};

const loginReducer = (state = false, action) => {
  if (action.type === "로그인") {
    localStorage.setItem("isLogin", true);
    return true;
  } else if (action.type === "로그아웃") {
    return false;
  } else return state;
};

const boardReducer = (state = {}, action) => {
  if (action.type === '게시글변경') {
    let board = action.payload;
    return board;
  }
  
  return state;
}

const boardListReducer = (state = [], action) => {
  if(action.type === '게시글목록변경') {
    let boardList = action.payload;
    return boardList;
  }
  return state;
}

const freeBoardReducer = (state = {}, action) => {
  if (action.type === '자유게시글변경') {
    let board = action.payload;
    return board;
  }
  
  return state;
}

const freeBoardListReducer = (state = [], action) => {
  if(action.type === '자유게시글목록변경') {
    let boardList = action.payload;
    return boardList;
  }
  return state;
}

const messageReducer = (state = {}, action) => {
  if(action.type === '메세지변경') {
    let messageData = action.payload;
    return messageData;
  }
  return state;
}

const alermReducer = (state = false, action) => {
  if(action.type === '알람변경') {
    state = !state;
  }
  return state;
}

const rootReducer = combineReducers({ chatReducer, userReducer, loginReducer, boardReducer, boardListReducer, messageReducer, alermReducer, freeBoardReducer, freeBoardListReducer});

export default rootReducer;
