import React from 'react'

export default function Footer() {
    return (
        <>
            {/* Footer */}
        <div className="footer bg-gray">
          <img className="decoration-city" src="/assets/images/decoration-city.svg" alt="alternative" />
          <div className="container">
            <div className="row">
                <div className="col-md-3 col-sm-6 col-6 section-info" style={{display:"inline-block", position:"relative", bottom:"30px", cursor : "pointer"}}>
                  <p style={{fontSize:'20px', fontWeight:'bold'}}>
                   팀
                  </p>
                  <p>
                   회사소개
                  </p>   
                  <p>
                   채용
                  </p>
                </div> {/* 팀 소개*/}


                <div className="col-md-3 col-sm-6 col-6 section-info" style={{display:"inline-block" , position:"relative", bottom:"30px", cursor : "pointer"}}>
                  <p style={{fontSize:'20px', fontWeight:'bold'}}>
                  비지니스 문의
                  </p>
                  <p>
                  서비스 소개서
                  </p>   
                  <p>
                  비지니스 제휴
                  </p>
                </div> {/* 안내 끝 */}

                <div className="col-md-3 col-sm-6 col-6 section-info" style={{display:"inline-block" , position:"relative", bottom:"30px", cursor : "pointer"}}>
                  <p style={{fontSize:'20px', fontWeight:'bold'}}>
                   안내
                  </p>
                  <p>
                  서비스 이용약관
                  </p>   
                  <p>
                  개인정보 처리방침
                  </p>
                </div> {/* 안내 끝 */}

                <div className="col-md-3 col-sm-6 col-6 section-info" style={{display:"inline-block" , position:"relative", bottom:"30px", cursor : "pointer"}}>
                  <p style={{fontSize:'20px', fontWeight:'bold'}}>
                   고객센터
                  </p>
                  <p>
                  T: 02-1234-5678(월-금 10~19시)
                  </p>   
                  <p>
                  E: support@WeTravel.com
                  </p>
                 
                </div> {/* 고객센터 끝 */}

                
            </div> {/* end of row */}
          </div> {/* end of container */}
        </div> {/* end of footer */}  
        {/* end of footer */}
        {/* Copyright */}
        <div className="copyright bg-gray">
          <div className="container">
            <div className="row">
              <div className="col-lg-6">
                <ul className="list-unstyled li-space-lg p-small">
                  <li>위트래블<br/>
                  서울특별시 금천구 가산동 426-5 월드 메르디앙 벤처 센터 2 차 410 호<br/>
                  대표자: 장나라 | 사업자등록번호: 123-45-67890 | 통신판매업신고: 2021-서울금천-0000
                  </li>
                </ul>
              </div> {/* end of col */}
              <div className="col-lg-6">
                <p className="p-small statement">Copyright © 2021 WeTravel Inc. All rights reserved.</p>

              </div> {/* end of col */}
           
            </div> {/* enf of row */}
          </div> {/* end of container */}
        </div> {/* end of copyright */} 
        {/* end of copyright */}
        </>
    )
}
