const ModalBtn = () => {
    return(
      <>
        <a className="btn-solid-reg" data-bs-toggle="modal" data-bs-target="#staticBackdrop">Modal</a>
      </>
    );
  }

export default ModalBtn;