import axios from 'axios';

const ModalWindow = (props) => {

  const 게시글삭제 = () => {
    const delConfirm = window.confirm('게시글을 삭제하시겠습니까?');
    if(delConfirm){
      axios.delete("http://localhost:8080/board" + props.code)
      .then(() => alert('게시글이 삭제되었습니다'));
    }
    
  }
  
    return(
      <>
        <div id="staticBackdrop" className="modal fade" tabIndex={-1} aria-hidden="true">
            <div className="modal-dialog">
              <div className="modal-content">
                <div className="row">
                  <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close" />
                  <div className="col-lg-8">
                    <div className="image-container">
                      <img className="img-fluid" src={props.image} alt="alternative" />
                    </div> {/* end of image-container */}
                  </div> {/* end of col */}
                  <div className="col-lg-4">
                    <h3>{props.제목}</h3>
                    <hr />
                    <p>{props.내용}</p>
                    <h4>User Feedback</h4>
                    <p>Sapien vitae eros. Praesent ut erat a tellus posuere nisi more thico cursus pharetra finibus posuere nisi. Vivamus feugiat</p>
                    <ul className="list-unstyled li-space-lg">
                      <li className="d-flex">
                        <i className="fas fa-chevron-right" />
                        <div className="flex-grow-1">Tincidunt sem vel brita bet mala</div>
                      </li>
                      <li className="d-flex">
                        <i className="fas fa-chevron-right" />
                        <div className="flex-grow-1">Sapien condimentum sacoz sil necr</div>
                      </li>
                      <li className="d-flex">
                        <i className="fas fa-chevron-right" />
                        <div className="flex-grow-1">Fusce interdum nec ravon fro urna</div>
                      </li>
                      <li className="d-flex">
                        <i className="fas fa-chevron-right" />
                        <div className="flex-grow-1">Integer pulvinar biolot bat tortor</div>
                      </li>
                      <li className="d-flex">
                        <i className="fas fa-chevron-right" />
                        <div className="flex-grow-1">Id ultricies fringilla fangor raq trinit</div>
                      </li>
                    </ul>
                    <a id="modalCtaBtn" className="btn-solid-reg" href="#">수정</a>
                    <button type="button" onClick={게시글삭제} style={{marginRight : "10px"}}>삭제</button>
                    <button type="button" className="btn-outline-reg" data-bs-dismiss="modal">닫기</button>
                  </div> {/* end of col */}
                </div> {/* end of row */}
              </div> {/* end of modal-content */}
            </div> {/* end of modal-dialog */}
          </div> {/* end of modal */}
      </>
    );
  }

export default ModalWindow;