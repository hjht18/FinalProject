// import React, { useEffect, useState } from "react";
// import ScrollToBottom from "react-scroll-to-bottom";
// import './chat.css'
// import { useHistory } from 'react-router';

// function Chat({ socket, username, room }) {
//   const [currentMessage, setCurrentMessage] = useState("");
//   const [messageList, setMessageList] = useState([]);     // DB에서 값을 받아서 여기에 설정
//   const history = useHistory();
//   const sendMessage = async () => {
//     if (currentMessage !== "") {

      
//       const messageData = {
//         room: room,
//         author: username,
//         message: currentMessage,
//         time:
//           new Date(Date.now()).getHours() +
//           ":" +
//           (new Date(Date.now()).getMinutes() < 10 ? '0' : '') + new Date(Date.now()).getMinutes(),
//       };

//       await socket.emit("send_message", messageData);
//       setMessageList((list) => [...list, messageData]);
//       setCurrentMessage("");
//       console.log(messageData);                         // 이 정보를 DB에 저장! ({room, author, message, time})
//     }
//   };

//   useEffect(() => {
//     socket.on("receive_message", (data) => {
//       setMessageList((list) => [...list, data]);
//     });
//   }, [socket]);

//   return (
//     <div className="chat-window">
//       <div className="chat-header">
//       <div id="less_than" onClick={() => {
//           const confirm = window.confirm('채팅방을 나가시겠습니까?');
//           if(confirm){
//             history.goBack();
//           }
//         }} >&lt;</div>
//       <div id="user_nick">CHAT</div>   {/* 상대방 아이디 */}
//       </div>
//       <div className="chat-body">
//         <ScrollToBottom className="message-container">
//           {messageList.map((messageContent) => {
//             return (
//               <div
//                 className="message"
//                 id={username === messageContent.author ? "other" : "you"}
//               >
//                 <div>
//                   <div className="message-content">
//                     <p>{messageContent.message}</p>
//                   </div>
//                   <div className="message-meta">
//                     <p id="time">{messageContent.time}</p>
//                     {/* <p id="author">{messageContent.author}</p> */}
//                   </div>
//                 </div>
//               </div>
//             );
//           })}
//         </ScrollToBottom>
//       </div>
//       <div className="chat-footer">
//         <textarea
//           type="text"
//           value={currentMessage}
//           placeholder="메세지를 입력해주세요"
//           onChange={(event) => {
//             setCurrentMessage(event.target.value);
//           }}
//           onKeyPress={(event) => {
//             event.key === "Enter" && sendMessage();
//           }}
//         />
//         <button id="send_btn" onClick={sendMessage}>보내기</button>
//         {/* <button onClick={() => {
//           const confirm = window.confirm('채팅방을 나가시겠습니까?');
//           if(confirm){
//             history.goBack();
//           }
//         }} style={{color : "black", fontSize : "12px"}}>나가기</button> */}
//       </div>
//     </div>
//   );
// }

// export default Chat;