//package com.spring.admin.controller;
//
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpSession;
//
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//
//import com.spring.admin.domain.UserVO;
//
//@Controller
//@CrossOrigin
//public class UserController {
//
//	@PostMapping("/getUser")
//	public void getUser(@RequestBody UserVO vo, HttpServletRequest request, Model model) {
//		HttpSession session = request.getSession();
//		if(vo != null) {
////			session.setAttribute("user", vo.getName());
//			model.addAttribute("user", vo);
//			System.out.println(vo.getName());
//		}
////		UserVO user = (UserVO)session.getAttribute("user");
////		System.out.println(user.getBasicAddress());
//	}
//}
