package com.spring.admin.dao;

import java.util.List;
import java.util.Map;

import com.spring.admin.domain.BoardVO;
import com.spring.admin.domain.UserVO;

public interface BoardDAO {
 
	public UserVO select(Long code) throws Exception;
    
    //게시글 작성
    public void write(BoardVO vo) throws Exception;
    
    //게시글 상세조회
    public BoardVO view(int admin_number) throws Exception;
    
     // 게시물 수정
    public void modify(BoardVO vo) throws Exception;
    
    // 게시뮬 삭제
    public void delete(int admin_number) throws Exception;
    
    // 게시물 총 갯수
    public int count(String searchType, String keyword) throws Exception;
    
    
    // 게시물 목록 + 페이징 + 검색
    public List<BoardVO> listPage(
      int displayPost, int postNum, String searchType, String keyword) throws Exception;
    
    // 파일 업로드
    public void insertFile(Map<String, Object> map) throws Exception;
    
    // 첨부파일 조회
    public List<Map<String, Object>> selectFileList(int admin_number) throws Exception;
    
    // 첨부파일 다운
 	public Map<String, Object> selectFileInfo(Map<String, Object> map) throws Exception;
 	
 	
 	// 첨부파일 수정
 	public void updateFile(Map<String, Object> map) throws Exception;
 	
    
    
}