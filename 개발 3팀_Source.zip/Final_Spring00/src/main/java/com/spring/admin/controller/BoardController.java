package com.spring.admin.controller;

import java.io.File;
import java.net.URLEncoder;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.spring.admin.domain.BoardVO;
import com.spring.admin.domain.UserVO;
import com.spring.admin.service.BoardService;

@Controller
@RequestMapping("/board/*")
@CrossOrigin
public class BoardController {

	@Autowired
	private BoardService service;
	
	// 게시글 목록 + 페이징 + 검색
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public void getList(Model model, @RequestParam("num") int num, 
			@RequestParam(value = "searchType",required = false, defaultValue = "title") String searchType,
			   @RequestParam(value = "keyword",required = false, defaultValue = "") String keyword, HttpServletRequest request,
			   @RequestParam(value = "code", required = false) Long code
			  ) throws Exception {
	 
	
		System.out.println("컨트롤러 보기");
		List<BoardVO> list = null;
		
		// 게시물 총 개수
		int count = service.count(searchType, keyword);
		
		// 한페이지에 출력할 게시물 갯수
		int amount = 10;
		
		int postNum = num * amount;
		
		// 하단 페이징 번호 ([ 게시물 총 갯수 ÷ 한 페이지에 출력할 갯수 ]의 올림)
		int pageNum = (int)Math.ceil((double)count/amount);
		  
		// 출력할 게시물
		int displayPost = (num - 1) * amount;
		
		// 한번에 표시할 페이징 번호의 갯수
		int pageNum_cnt = 10;

		// 표시되는 페이지 번호 중 마지막 번호
		int endPageNum = (int)(Math.ceil((double)num / (double)pageNum_cnt) * pageNum_cnt);

		// 표시되는 페이지 번호 중 첫번째 번호
		int startPageNum = endPageNum - (pageNum_cnt - 1);
		
		// 마지막 번호 재계산
		int endPageNum_tmp = (int)(Math.ceil((double)count / (double)pageNum_cnt));
		 
		if(endPageNum > endPageNum_tmp) {
		 endPageNum = endPageNum_tmp;
		}
		
		boolean prev = startPageNum == 1 ? false : true;
		boolean next = endPageNum * pageNum_cnt >= count ? false : true;
		
		
		list = service.listPage(displayPost, postNum, searchType, keyword);
		model.addAttribute("list", list);
		model.addAttribute("pageNum", pageNum);
		
		
		// 시작 및 끝 번호
		model.addAttribute("startPageNum", startPageNum);
		model.addAttribute("endPageNum", endPageNum);

		// 이전 및 다음 
		model.addAttribute("prev", prev);
		model.addAttribute("next", next);
		
		// 현재 페이지
		model.addAttribute("select", num);
		model.addAttribute("searchType", searchType);
		model.addAttribute("keyword", keyword);
		
		String searchTypeKeyword;
		
		if(searchType.equals("") || keyword.equals("")) {
			  searchTypeKeyword = ""; 
			 } else {
			  searchTypeKeyword = "&searchType=" + searchType + "&keyword=" + keyword; 
			 }
		model.addAttribute("searchTypeKeyword", searchTypeKeyword);
		
		// 가입한 이름 넣어주면 됨
		// 리액트에서 get으로 파라미터이름 name으로 못넘겨줄까요?
		// user이름으로 select mapper 작성해서 아래처럼 만들긴 했는데
		// get으로 값을 못넘겨받아서..ㅠㅠ
		
		// name값만 받아오면 mapper에서 읽어올수 있는데
		// 할줄 몰라서 가입할때 입력한 이름을 아래 name에 강제로 입력하면
		
		// navibar에서  ${user.name} 이나 ${user.id} 하면 값 받아와서 
		// 네비바에 나오긴 합니다.
		
		UserVO user = service.select(code);
		HttpSession session = request.getSession();
		session.setAttribute("user", user);
		if(user != null) {
			UserVO findUser = (UserVO)session.getAttribute("user");
			int admin = findUser.getRole();
			System.out.println(admin);
			if(admin == 9) {
				session.setAttribute("isadminLogin", true);
				System.out.println("관리자 로그인");
			} else {
				session.setAttribute("isLogin", true);
				System.out.println("유저 로그인");
			}
		} 
		
	}
	
	// 로그아웃
	@RequestMapping("/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/board/list?num=1";
	}
	
	
	
	// 게시물 작성
	 @RequestMapping(value = "/write", method = RequestMethod.GET)
	 public void getWirte(HttpServletRequest request) throws Exception {

	 }
	 
	// 게시물 작성
	@RequestMapping(value = "/write", method = RequestMethod.POST)
	public String postWrirte(BoardVO vo, HttpServletRequest request, RedirectAttributes rttr, MultipartHttpServletRequest mpRequest
			) throws Exception{
		
		HttpSession session = request.getSession();
		UserVO user = (UserVO)session.getAttribute("user");
		System.out.println(user.getName());
		int code1 = user.getCode().intValue();
		System.out.println(code1);
		
		// 작성
		service.write(vo, mpRequest);
		rttr.addFlashAttribute("result", "write success");
		
		
		return "redirect:/board/list?num=1&code=" + code1;
		
	}
	
	// 게시물 조회
	@RequestMapping(value = "/view", method = RequestMethod.GET)
	public void getView(@RequestParam("admin_number") int admin_number, Model model) throws Exception {
		
		System.out.println("컨트롤러 조회");
		BoardVO vo = service.view(admin_number);
		model.addAttribute("view", vo);
		
		List<Map<String, Object>> fileList = service.selectFileList(admin_number);
		model.addAttribute("file", fileList);
		
	}
	
	// 게시물 수정
	@RequestMapping(value = "/modify", method = RequestMethod.GET)
	public void getModify(@RequestParam("admin_number") int admin_number, Model model) throws Exception {
		BoardVO vo = service.view(admin_number);
		model.addAttribute("view", vo);
		
		List<Map<String, Object>> fileList = service.selectFileList(admin_number);
		model.addAttribute("file", fileList);
	}
	
	// 게시물 수정
	@RequestMapping(value = "/modify", method = RequestMethod.POST)
	public String postModify(BoardVO vo, RedirectAttributes rttr,
			@RequestParam(value="fileNoDel[]") String[] files,
			 @RequestParam(value="fileNameDel[]") String[] fileNames,
			 MultipartHttpServletRequest mpRequest) throws Exception {
		rttr.addFlashAttribute("result", "modify success");
		service.modify(vo, files, fileNames, mpRequest);
		return "redirect:/board/view?admin_number=" + vo.getAdmin_number();
	}
	
	// 게시물 삭제
	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	public String getDelete(@RequestParam("admin_number") int admin_number, RedirectAttributes rttr, HttpServletRequest request) throws Exception {
		rttr.addFlashAttribute("result", "delete success");
		service.delete(admin_number); 
		
		HttpSession session = request.getSession();
		UserVO user = (UserVO)session.getAttribute("user");
		int code1 = user.getCode().intValue();
		
		return "redirect:/board/list?num=1&code=" + code1;
		
	}
	
	@RequestMapping(value="/fileDown")
	public void fileDown(@RequestParam Map<String, Object> map, HttpServletResponse response) throws Exception{
		Map<String, Object> resultMap = service.selectFileInfo(map);
		String storedFileName = (String) resultMap.get("STORED_FILE_NAME");
		String originalFileName = (String) resultMap.get("ORG_FILE_NAME");
		
		// 파일을 저장했던 위치에서 첨부파일을 읽어 byte[]형식으로 변환한다.
		byte fileByte[] = org.apache.commons.io.FileUtils.readFileToByteArray(new File("C:\\mp\\file\\" + storedFileName));
		
		response.setContentType("application/octet-stream");
		response.setContentLength(fileByte.length);
		response.setHeader("Content-Disposition",  "attachment; fileName=\""+URLEncoder.encode(originalFileName, "UTF-8")+"\";");
		response.getOutputStream().write(fileByte);
		response.getOutputStream().flush();
		response.getOutputStream().close();
		
	}

}