package com.spring.admin.service;

import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.spring.admin.domain.BoardVO;
import com.spring.admin.domain.UserVO;

public interface BoardService {

	public UserVO select(Long code) throws Exception;
	
	//게시글 작성
	public void write(BoardVO vo, MultipartHttpServletRequest mpRequest) throws Exception;
	
	// 게시물 조회
	public BoardVO view(int admin_number) throws Exception;
	
	// 게시물 수정
	public void modify(BoardVO vo, String[] files, String[] fileNames, MultipartHttpServletRequest mpRequest) throws Exception;
	
	// 게시물 삭제
	public void delete(int admin_number) throws Exception;
	
	// 게시물 총 갯수
	public int count(String searchType, String keyword) throws Exception;
	
	// 게시물 목록 + 페이징 + 검색
	public List<BoardVO> listPage(
	  int displayPost, int postNum, String searchType, String keyword) throws Exception;
	
	// 첨부파일 조회
	public List<Map<String, Object>> selectFileList(int admin_number) throws Exception;
	
	// 첨부파일 다운
	public Map<String, Object> selectFileInfo(Map<String, Object> map) throws Exception;
	
	
	
}
