package com.spring.admin.service;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.spring.admin.dao.BoardDAO;
import com.spring.admin.domain.BoardVO;
import com.spring.admin.domain.FileUtils;
import com.spring.admin.domain.UserVO;

@Service
public class BoardServiceImpl implements BoardService {

	@Autowired
	private BoardDAO dao;
 
	@Resource(name = "fileUtils")
	private FileUtils fileUtils;
	
	
	@Override
	public UserVO select(Long code) throws Exception {
		
		return dao.select(code);
	}
	
	
	
	// 게시글 작성
	@Override
	public void write(BoardVO vo, MultipartHttpServletRequest mpRequest) throws Exception {
		dao.write(vo);
		
		// 파일 업로드
		List<Map<String,Object>> list = fileUtils.parseInsertFileInfo(vo, mpRequest); 
		int size = list.size();
		for(int i=0; i<size; i++){ 
			dao.insertFile(list.get(i)); 
		}
	}
	
	// 첨부파일 조회
	@Override
	public List<Map<String, Object>> selectFileList(int admin_number) throws Exception {
		return dao.selectFileList(admin_number);
	}

	// 게시글 보기
	@Override
	public BoardVO view(int admin_number) throws Exception {
		System.out.println("서비스 조회");
		return dao.view(admin_number);
	}

	// 게시글 수정
	@Override
	public void modify(BoardVO vo, String[] files, String[] fileNames, MultipartHttpServletRequest mpRequest) throws Exception {
		dao.modify(vo);
		
		List<Map<String, Object>> list = fileUtils.parseUpdateFileInfo(vo, files, fileNames, mpRequest);
		Map<String, Object> tempMap = null;
		int size = list.size();
		for(int i = 0; i<size; i++) {
			tempMap = list.get(i);
			if(tempMap.get("IS_NEW").equals("Y")) {
				dao.insertFile(tempMap);
			}else {
				dao.updateFile(tempMap);
			}
		}
	}
	
	// 게시물 삭제
	public void delete(int admin_number) throws Exception {
		dao.delete(admin_number);
	}

	// 게시물 총 갯수
	@Override
	public int count(String searchType, String keyword) throws Exception {
		return dao.count(searchType, keyword);
	}
	
	// 게시물 목록 + 페이징 + 검색
	@Override
	public List<BoardVO> listPage(
	  int displayPost, int postNum, String searchType, String keyword) throws Exception {
	 return  dao.listPage(displayPost, postNum, searchType, keyword);
	}
	
	// 첨부파일 다운로드
	@Override
	public Map<String, Object> selectFileInfo(Map<String, Object> map) throws Exception {
		return dao.selectFileInfo(map);
	}

	

}