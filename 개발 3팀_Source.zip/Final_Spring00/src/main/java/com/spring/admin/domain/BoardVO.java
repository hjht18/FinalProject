package com.spring.admin.domain;

import java.util.Date;

public class BoardVO {

	private int admin_number;
	private String admin_writer;
	private String admin_title;
	private Date admin_date;
	private String admin_content;
	private String admin_image;
	
	public BoardVO() {
	}
	
	public BoardVO(int admin_number, String admin_writer, String admin_title, Date admin_date, String admin_content,
			String admin_image) {
		super();
		this.admin_number = admin_number;
		this.admin_writer = admin_writer;
		this.admin_title = admin_title;
		this.admin_date = admin_date;
		this.admin_content = admin_content;
		this.admin_image = admin_image;
	}
	public int getAdmin_number() {
		return admin_number;
	}
	public void setAdmin_number(int admin_number) {
		this.admin_number = admin_number;
	}
	public String getAdmin_writer() {
		return admin_writer;
	}
	public void setAdmin_writer(String admin_writer) {
		this.admin_writer = admin_writer;
	}
	public String getAdmin_title() {
		return admin_title;
	}
	public void setAdmin_title(String admin_title) {
		this.admin_title = admin_title;
	}
	public Date getAdmin_date() {
		return admin_date;
	}
	public void setAdmin_date(Date admin_date) {
		this.admin_date = admin_date;
	}
	public String getAdmin_content() {
		return admin_content;
	}
	public void setAdmin_content(String admin_content) {
		this.admin_content = admin_content;
	}
	public String getAdmin_image() {
		return admin_image;
	}
	public void setAdmin_image(String admin_image) {
		this.admin_image = admin_image;
	}
	
	
}
