package com.spring.admin.domain;

public class UserVO {
	

	private Long USER_CODE;
	
	private String id;
	
	private String name;
	
	private String password;
	
	private String gender;
	
	private String phoneNum;
	
	private String zipCode;
	
	private String basicAddress;
	
	private String detailAddress;
	
	private String image;
	
	private int role;
	
	
	public UserVO() {}
	

	public UserVO(Long code, String id, String name, String password, String gender, String phoneNum, String zipCode,
			String basicAddress, String detailAddress, String image) {
		super();
		this.USER_CODE = code;
		this.id = id;
		this.name = name;
		this.password = password;
		this.gender = gender;
		this.phoneNum = phoneNum;
		this.zipCode = zipCode;
		this.basicAddress = basicAddress;
		this.detailAddress = detailAddress;
		this.image = image;
	}

	public Long getCode() {
		return USER_CODE;
	}

	public String getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public String getPassword() {
		return password;
	}

	public String getGender() {
		return gender;
	}

	public String getPhoneNum() {
		return phoneNum;
	}

	public String getZipCode() {
		return zipCode;
	}

	public String getBasicAddress() {
		return basicAddress;
	}

	public String getDetailAddress() {
		return detailAddress;
	}

	public String getImage() {
		return image;
	}

	public void setCode(Long code) {
		this.USER_CODE = code;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public void setBasicAddress(String basicAddress) {
		this.basicAddress = basicAddress;
	}

	public void setDetailAddress(String detailAddress) {
		this.detailAddress = detailAddress;
	}

	public int getRole() {
		return role;
	}


	public void setRole(int role) {
		this.role = role;
	}


	public void setImage(String image) {
		this.image = image;
	}
	
	
}
