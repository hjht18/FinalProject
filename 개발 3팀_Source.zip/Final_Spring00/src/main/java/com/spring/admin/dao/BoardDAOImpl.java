package com.spring.admin.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.admin.domain.BoardVO;
import com.spring.admin.domain.UserVO;

@Repository
public class BoardDAOImpl implements BoardDAO{
	
	@Autowired
	private SqlSession sql;
	
	private static String namespace = "com.spring.admin.domain.BoardVO";
	private static String namespace1 = "com.spring.admin.domain.UserVO";

	@Override
	public UserVO select(Long code) throws Exception {
		return sql.selectOne(namespace1+".select", code);
	}
	
	// 게시글 등록
	@Override
	public void write(BoardVO vo) throws Exception {
		sql.insert(namespace + ".write", vo);
	}

	// 게시물 조회
	@Override
	public BoardVO view(int admin_number) throws Exception {
		System.out.println("다오 조회");
		return sql.selectOne(namespace + ".view", admin_number);
	}

	// 게시글 수정
	@Override
	public void modify(BoardVO vo) throws Exception {
		sql.update(namespace + ".modify", vo);
	}
	
	// 게시물 삭제
	public void delete(int admin_number) throws Exception {
	 sql.delete(namespace + ".delete", admin_number);
	}
	
	// 게시물 총 갯수
	@Override
	public int count(String searchType, String keyword) throws Exception {
		HashMap<String, String> data = new HashMap<String, String>();
		data.put("searchType", searchType);
		data.put("keyword", keyword);
	 return sql.selectOne(namespace + ".count", data); 
	}
	
	// 게시물 목록 + 페이징 + 검색
	 @Override
	 public List<BoardVO> listPage(
	   int displayPost, int postNum, String searchType, String keyword) throws Exception {

	  HashMap<String, Object> data = new HashMap<String, Object>();
	  
	  data.put("displayPost", displayPost);
	  data.put("postNum", postNum);
	  
	  data.put("searchType", searchType);
	  data.put("keyword", keyword);
	  
	  return sql.selectList(namespace + ".listPage", data);
	 }
	 
	// 첨부파일 업로드
	@Override
	public void insertFile(Map<String, Object> map) throws Exception {
		sql.insert(namespace + ".insertFile", map);
	}
	
	// 첨부파일 조회
	@Override
	public List<Map<String, Object>> selectFileList(int admin_number) throws Exception {
		return sql.selectList(namespace + ".selectFileList", admin_number);
	}
	
	// 첨부파일 다운로드
	@Override
	public Map<String, Object> selectFileInfo(Map<String, Object> map) throws Exception {
		return sql.selectOne(namespace + ".selectFileInfo", map);
	}
	
	@Override
	public void updateFile(Map<String, Object> map) throws Exception {
		// TODO Auto-generated method stub
		
		sql.update(namespace + ".updateFile", map);
	}

	
	
}
